package org.cap.trackingservice;

public class InvalidGoalException extends Exception {

	public InvalidGoalException(){
		
	}
	
	@Override
	public String getMessage(){
		return "Goal should be greater than zero!";
	}
}
