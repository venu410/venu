package org.cap.trackingservice;

public class Product {
	
	private int productId;
	private int amount;
	private int total;
	private String opeartion;
	
	public Product(){}
	
	public Product(int productId, int amount, int total, String opeartion) {
		super();
		this.productId = productId;
		this.amount = amount;
		this.total = total;
		this.opeartion = opeartion;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public String getOpeartion() {
		return opeartion;
	}
	public void setOpeartion(String opeartion) {
		this.opeartion = opeartion;
	}
	
	

}
