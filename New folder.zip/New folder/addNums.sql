DELIMITER $$

CREATE
    
    PROCEDURE `capdb`.`addNumbers`(IN num1 INT,IN num2 INT,
    OUT answer INT)
      
    BEGIN
	
	SET answer=num1+num2;
   
    END$$

DELIMITER ;

