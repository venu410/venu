DELIMITER $$

CREATE
   
    PROCEDURE `capdb`.`findEmployee`(employeeId INT,OUT empName VARCHAR(100))
   
    BEGIN
	DECLARE fname VARCHAR(50);
	DECLARE lname VARCHAR(50);
	
	SELECT firstName,lastName INTO fname,lname FROM employee WHERE empId=employeeId;
	
	SET empName=CONCAT(fname,' ' ,lname);
	
    END$$

DELIMITER ;