DELIMITER $$

CREATE
   
    PROCEDURE `capdb`.`listEmail`(IN deptId INT,OUT empEmail VARCHAR(300))
   
    BEGIN
	DECLARE allEmail VARCHAR(300) DEFAULT ' ';
	DECLARE finished INT DEFAULT 0;
	DECLARE curEmail VARCHAR(20);
	DECLARE empEmail_Cur CURSOR FOR 
		SELECT email FROM employee WHERE departId=deptId;
	
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished=1;
	
	OPEN empEmail_Cur;
	
	WHILE finished=0 DO
		FETCH empEmail_Cur INTO curEmail;
		SET allEmail=CONCAT(allEmail,';',curEmail);
	END WHILE;
	
	SET empEmail=allEmail;
	
	CLOSE empEmail_Cur;

    END$$

DELIMITER ;