CREATE DATABASE capdb

CREATE TABLE employee(empid INT PRIMARY KEY,firstname VARCHAR(50) UNIQUE,
lastname VARCHAR(50) NOT NULL,
salary DECIMAL(8,2) DEFAULT 2000,
departId INT REFERENCES department(depid) ON DELETE CASCADE
);

CREATE TABLE employee(empid INT PRIMARY KEY,firstname VARCHAR(50) UNIQUE,
lastname VARCHAR(50) NOT NULL,
salary DECIMAL(8,2) DEFAULT 2000,
departId INT,FOREIGN KEY(departid) REFERENCES department(depid) ON DELETE CASCADE
);


ALTER TABLE employee MODIFY(departId INT,FOREIGN KEY(departId) REFERENCES department(depid) CASCADE ON DELETE);

CREATE TABLE employee(empid INT PRIMARY KEY,firstname VARCHAR(50) UNIQUE,
lastname VARCHAR(50) NOT NULL,
salary DECIMAL(8,2), CHECK(salary>20000.0),empdob DATE);

DROP TABLE employee;

ALTER TABLE employee MODIFY lastname VARCHAR(10) NOT NULL;

ALTER TABLE employee MODIFY firstname VARCHAR(10) UNIQUE;

ALTER TABLE employee MODIFY salary DECIMAL(8,2) DEFAULT 2000;



ALTER TABLE employee ADD empdob DATE;

DESC employee

INSERT INTO employee VALUES(11,'tom','jerry',23000,1);


INSERT INTO employee VALUES(1001,'ram','singh',13000,2);

INSERT INTO employee VALUES(1005,'hari','singh',13000,12);

INSERT INTO employee(empid,firstname) VALUES(167,'Annie');

INSERT INTO employee(lastname,empid,empdob) VALUES('Ken',1009,'1999-01-12');

INSERT INTO employee(firstname,lastname) VALUES('ram','singh');
INSERT INTO employee(firstname,lastname) VALUES('kamal','singh');


SELECT * FROM employee WHERE salary IS NULL;
SELECT * FROM employee WHERE lastname IS NULL;

TRUNCATE TABLE employee;

UPDATE employee SET salary=3000;

UPDATE employee SET salary=25000, empdob='1899-12-12' WHERE empid=1001;


DELETE FROM employee;



DELETE FROM employee WHERE empid=1001;

ALTER TABLE employee DROP COLUMN lastname;

SELECT * FROM employee WHERE empid>100;


CREATE TABLE department (depid INT PRIMARY KEY, depname VARCHAR(10));

SELECT * FROM department;
SELECT * FROM employee ;
INSERT INTO department VALUES(1,'sales');
INSERT INTO department VALUES(2,'finance');
INSERT INTO department VALUES(3,'marketing');
INSERT INTO department VALUES(12,'purchase');

DELETE FROM department WHERE depid=2;


CREATE TABLE event (eventid INT AUTO_INCREMENT PRIMARY KEY,
eventname VARCHAR(10)); 

INSERT INTO event VALUES(1001,'java');

INSERT INTO event(eventname) VALUES('oracle');

SELECT * FROM event;

SELECT SYSDATE();



