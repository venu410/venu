SELECT * FROM employee;

CALL listEmail(1,@empEmail);
SELECT @empEmail;

DROP PROCEDURE listEmail;