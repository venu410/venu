SELECT * FROM employee;
USE capdb;

SELECT * FROM event;

CREATE VIEW empView AS
SELECT empid,firstName,departId FROM employee WHERE salary>20000;

UPDATE empView SET firstName='jasmine' WHERE empId=11;


SELECT * FROM empView;

INSERT INTO empView VALUES(198,'annie',1);


DROP VIEW empView;



CALL addNumbers(100,200,@value1);
SELECT @value1;

CALL printName('Tom','Jerry',@out_value);
SELECT @out_value;

DROP PROCEDURE `capdb`.`addNumbers`;



SELECT findMax(12,-45,90);


SELECT firstname,lastname FROM employee WHERE salary>10000;

CALL findEmployee(1005,@ename);
SELECT @ename;

DROP PROCEDURE listEmployees;

CALL listEmployees(@value1);
SELECT @value1;


