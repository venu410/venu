DELIMITER $$

CREATE
   
    PROCEDURE `capdb`.`printName`(IN firstName VARCHAR(50),IN lastName VARCHAR(50),
	OUT greetings VARCHAR(50))
   
    BEGIN
	DECLARE msg VARCHAR(100);
	SET msg=CONCAT('Hello! ', firstName,' ', lastName);
	SET greetings=msg;

    END$$

DELIMITER ;