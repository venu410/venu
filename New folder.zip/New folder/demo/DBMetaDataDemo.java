package org.capgemini.demo;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class DBMetaDataDemo {

	public static void main(String[] args) {
		Connection conn=null;
		try {
			
			//Load Driver Class
			Class.forName("com.mysql.jdbc.Driver");
			
			//Establish Connection
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","admin");
		
			DatabaseMetaData dbinfo=conn.getMetaData();
			System.out.println(dbinfo.getDatabaseProductName());
			System.out.println(dbinfo.getDatabaseMajorVersion());
			System.out.println(dbinfo.getDatabaseMinorVersion());
			System.out.println(dbinfo.getDatabaseProductVersion());
		
			System.out.println(dbinfo.getDriverName());
			//System.out.println(dbinfo.get);
			
			Statement stmt=conn.createStatement();
			
			String sql="select * from employee";
			
			ResultSet rs=stmt.executeQuery(sql);
			
			ResultSetMetaData rsinfo=rs.getMetaData();
			
			System.out.println(rsinfo.getColumnCount());
			System.out.println(rsinfo.getColumnTypeName(1));
			
		
			
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
