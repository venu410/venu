package org.capgemini.demo;

public interface EmployeeDao {
	
	public int addEmployee(Employee employee);

}
