package first.project;

public class EmpBonus {

	public static void main(String[] args) {
		EmpDetails emp=new EmpDetails();
		emp.getEmpDetails();
		emp.showEmpDetails();
	}

}
