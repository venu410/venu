package first.project;

import java.util.Scanner;

public class EmpDetails {
	//instance variable
	private String empName;
	private Double salary;
	public void getEmpDetails()
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("enter name of the employee :");
		empName=scan.next();
		System.out.println("enter salary of the employee :");
		salary=scan.nextDouble();	
		scan.close();
	}
	//calculating employee bonus
	public double calculateBonus(){
		double bonus=0.0;
		if(salary>2000000)
			bonus=salary*0.15;
		else if(salary>1000000)
			bonus=salary*0.20;
		else if(salary>500000)
			bonus=salary*0.25;
		else
			bonus=salary*0.30;
		return bonus;	
				
	}
	//showing employee details
	public void showEmpDetails(){
		System.out.println("\n\n name of the employee :"+empName+"\n salary of the employee:"+salary+"\n bonus of the employee:"+calculateBonus());
		
	}
	

}
