package first.project;

public class Pattern {

}
