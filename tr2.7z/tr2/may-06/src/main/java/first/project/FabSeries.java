package first.project;

import java.util.Scanner;

public class FabSeries {
	public void series(){
		Scanner scan=new Scanner(System.in);
		System.out.println("enter number ");
		int n=scan.nextInt();
		int a=0;
		int b=1;
		int c;
		System.out.print("The fabinocai series is: "+a);
		System.out.print(" "+b);
		for(int i=1;i<=n;i++){
			 c=a+b;
			 a=b;
			 b=c;			
		System.out.print(" "+c);
		scan.close();
		}
		
	}

	public static void main(String[] args) {
		FabSeries f=new FabSeries();
		f.series();

	}

}
