package first.project;

public class Digi {

}
