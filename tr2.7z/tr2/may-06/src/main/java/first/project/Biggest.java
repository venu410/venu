
package first.project;
import java.util.Scanner;

public class Biggest {
	public void large(){
	Scanner scan=new Scanner(System.in);
	System.out.println("enter 1st number");
	int a=scan.nextInt();	
	System.out.println("enter 2nd number");
	int b=scan.nextInt();	
	System.out.println("enter 3rd number");
	int c=scan.nextInt();
	if(a>b&&a>c)
	{
		System.out.println("The biggest number is:"+a);
	}
	else if(b>a&&b>c)
	{
		System.out.println("The biggest number is:"+b);
	}
	else
	{
		System.out.println("The biggest number is:"+c);
	}
	scan.close();
}	
		
	
	public static void main(String[] args) {
		Biggest b=new Biggest();
		b.large();
	}

}
