package first.project;

import java.util.Scanner;

public class Bonus {
	public void empBonus(){		
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter Name");
	String name=scan.nextLine();
	System.out.println("Enter salary");
	double sal=scan.nextDouble();
			
	if(sal>2000000){
		System.out.println("bonus of "+name+" is:"+((sal*15)/100));
	}
	else if(sal<2000000&&sal>1000000){
		System.out.println("bonus of "+name+" is:"+((sal*20)/100));
		
	}
	else if(sal<1000000&&sal>500000){
		System.out.println("bonus of "+name+" is:"+((sal*25)/100));
		
	}
	else if(sal<500000){
		System.out.println("bonus of "+name+" is:"+((sal*30)/100));
		
	}
	
	scan.close();
	}

	public static void main(String[] args) {
		Bonus b=new Bonus();
		b.empBonus();
		

	}

}
