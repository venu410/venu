package first.project;

public class MyProgram 
{
	public static void main(String[] args) 
	{		
		System.out.println("Hello World");
	}

}
