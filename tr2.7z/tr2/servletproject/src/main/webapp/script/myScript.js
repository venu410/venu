function displaySalary(){
	
	var sal=empForm.empSalary.value;
	//alert(sal);
	document.getElementById('divSal').innerHTML='<b>'+sal+'</b>';
	
}