package org.cap.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.login.pojo.Employee;
import org.cap.login.service.LoginService;
import org.cap.login.service.LoginServiceImpl;

public class UpdateEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		int empId=Integer.parseInt(request.getParameter("employeeId"));
		
		LoginService loginService=new LoginServiceImpl();
		Employee emp=loginService.searchEmployee(empId);
		
		String qualification=emp.getQualification();
		String[] qualifications=qualification.split(",");
		List<String> qualifyList=new ArrayList<String>();
		for(String s:qualifications)
			qualifyList.add(s);
		
		String gender=emp.getGender();
		
		
		
		
		out.println("<html><head><title>UpdateEmployee</title></head>"
				+ "<body>"
				+ "<form method='post' action='UpdateEmployee' >");
		
		out.println("<h1 align='center'>Update Emplyee</h1><hr>");	
		
		
		out.println("<table style='margin-left:200px;border:1px solid black;'>"
				+ "<tr>"
				+ "<td>Employee Id</td>"
				+ "<td>"+emp.getEmpId()+"</td>" 
				+ "</tr>"
				+ "<tr>"
				+ "<td>FirstName</td>"
				+ "<td><input type='text' name='fname' value='" + emp.getFirstName()+"' size='20'>"
				+ "</tr>"
				
				+"<tr>"
				+"<td>LastName</td>"
				+"<td><input type='text' name='lname' value='"+ emp.getLastName()+"'size='20'>"
				+ "</td>"
				+ "</tr>"
				
				+ "<tr>"
				+ "<td>email</td>"
				+ "<td><input type='text' name='email' value='"+emp.getEmail()+"'size='20'>"
				+ "</td>"
				+ "</tr>"
				
				+ "<tr>"
				+ "<td>salary</td>"
				+ "<td><input type='range' min='2000' step='10000' onchange='displaySalary()' name='empSalary' max='500000'"+emp.getSalary()+"'size='20'>"
				+ "</td>"
				+ "</tr>"
				
				+ "<tr>"
				+ "<td>DateOfBirth()</td>"
				+ "<td><input type='date' name='empDob' pattern=''value='"+emp.getEmpDob()+"' 'size='20'>"
				+ "</td>"
				+ "</tr>"
				

				+ "<tr>"
				+ "<td>DateOfJoining</td>"
				+ "<td><input type='date' name='empDoj'value='"+emp.getEmpDob()+"'>"
				+ "</td>"
				+ "</tr>"
				
				+ "<tr>"
				+ "<td>qualification</td>");
					if(qualifyList.contains("BE"))
						out.println("<td><input type='checkbox' checked='checked' name='chkQualification' value='"+emp.getQualification()+"'>BE");
					else
						out.println("<td><input type='checkbox' name='chkQualification' value='"+emp.getQualification()+"'>BE");

					if(qualifyList.contains("ME"))
						out.println("<input type='checkbox' checked='checked' name='chkQualification' value='"+emp.getQualification()+"'>ME");
					else
						out.println("<input type='checkbox' name='chkQualification' value='"+emp.getQualification()+"'>ME");

					if(qualifyList.contains("MBA"))
						out.println("<input type='checkbox' checked='checked' name='chkQualification' value='"+emp.getQualification()+"'>MBA");
					else
						out.println("<input type='checkbox' name='chkQualification' value='"+emp.getQualification()+"'>MBA");

					if(qualifyList.contains("BTECH"))
						out.println("<input type='checkbox' checked='checked' name='chkQualification' value='"+emp.getQualification()+"'>BTECH");
					else
						out.println("<input type='checkbox' name='chkQualification' value='"+emp.getQualification()+"'>BTECH");


				
				/*+ "<td><input type='checkbox' name='chkQualification' value='BE'> BE"
					+"<input type='checkbox' name='chkQualification' value='ME'> ME"
					+"<input type='checkbox' name='chkQualification' value='MBA'> MBA"
					+"<input type='checkbox' name='chkQualification' value='BTECH'> BTECH"+emp.getQualification()*/
				out.println("</td>"
				+ "</tr>"
				
				+ "<tr>"
				+ "<td>Gender</td>");
				if(gender.contains("Male"))
						{
				out.println("<td><input type='radio' checked='checked' name='gender' value='"+emp.getGender()+"'> Male"
					+"<input type='radio' name='gender' value='"+emp.getGender()+"'> Female</td>");
						}else
						{
							out.println("<td><input type='radio' name='gender' value='"+emp.getGender()+"'> Male"
									+"<input type='radio' checked='checked' name='gender' value='"+emp.getGender()+"'> Female</td>");
						}
					
				
				
				out.println( "</td>"
				+ "</tr>"
				
				+ "<tr>"
				+ "<td>Department</td>"
				+ "<td><select name='empDepart'>"
						+"<option value='1'>Sales</option>"
						+"<option value='2'>Purchase</option>"
						+"<option value='3'>Finance</option>"
						+"<option value='4'>Marketing</option></select>"+emp.getDepartment()
				+ "</td>"
				+ "</tr>"
				
				+ "<tr>"
				+ "<td>Address</td>"
				+ "<td><textarea rows='5' cols='20' name='empAddress' value='"+emp.getAddress()+"'></textarea>"
				+ "</td>"
				+ "</tr>"
				
				+"<tr>"
				+ "<td></td>"
				+ "<td><input type='submit' name='update' value='Update'>"
				+ "</tr>");
		
		
				
				
				out.println( "</table></form></body></html>");
		
		
		
		
	
	}

}
