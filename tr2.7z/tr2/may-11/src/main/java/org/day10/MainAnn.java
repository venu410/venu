package org.day10;

public class MainAnn {
	@AuthDemo(authorName="venu",bookName="MyLife",price=230.98,publishDate="12-12-1986")
	public static void main(String[] args) {
		
	}

}
