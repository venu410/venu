package org.day10;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.CLASS)

public @interface AuthDemo {
	String authorName();
	String bookName();
	String publishName() default "Resley";
	double price();
	String publishDate();	
}




