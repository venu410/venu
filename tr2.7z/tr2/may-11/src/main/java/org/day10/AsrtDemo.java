package org.day10;

import java.util.Scanner;

public class AsrtDemo {
	private double empSal;

	public void getSalary(){
		Scanner scan=new Scanner(System.in);
		System.out.println("enter employee salary");
		empSal=scan.nextDouble();
		scan.close();
		
	}
	public void calculateSalary(){
		assert empSal>10000:"salary should greater than 10000";
		System.out.println("salary"+empSal);
			
	}
}
