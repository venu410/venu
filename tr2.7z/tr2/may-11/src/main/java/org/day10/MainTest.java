package org.day10;

public class MainTest {

	public static void main(String[] args) {
		AsrtDemo asr=new AsrtDemo();
		asr.getSalary();
		asr.calculateSalary();

	}

}
