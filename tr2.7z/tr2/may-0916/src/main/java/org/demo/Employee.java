package org.demo;

import java.util.Scanner;

public class Employee {
	private int empId;
	private String firstName,lastName;
	private double salary;
	private WeekDays holiday;
	public void getDetails(){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter emp id:");
		empId=scan.nextInt();
		System.out.println("enter first name");
		firstName=scan.next();
		System.out.println("enter last name");
		firstName=scan.next();
		System.out.println("enter salary");
		salary=scan.nextDouble();
		
		
	}

}
