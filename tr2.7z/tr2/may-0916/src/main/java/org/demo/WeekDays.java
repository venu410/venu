package org.demo;

public enum WeekDays {

}
