package org.demo;

import java.util.Date;

public class Account {
	private int accountNumber;
	private String accountname;
	private Date opendate;
	private 
	

}
