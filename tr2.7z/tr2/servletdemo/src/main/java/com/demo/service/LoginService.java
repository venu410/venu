package com.demo.service;

import com.demo.pojo.Login;

public interface LoginService {
		
		public boolean isValidUser(Login login);
		
		
		

}



