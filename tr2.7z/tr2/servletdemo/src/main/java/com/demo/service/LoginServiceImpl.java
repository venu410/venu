package com.demo.service;

import com.demo.dao.LoginDAO;
import com.demo.dao.LoginDAOImpl;
import com.demo.pojo.Login;

public class LoginServiceImpl implements LoginService{
	LoginDAO logindao=new LoginDAOImpl();

		@Override
		public boolean isValidUser(Login login) {
			return logindao.isValidUser(login);
			/*if(login.getUserName().equals("venu") && login.getUserPwd().equals("kumar123"))
				return true;
				else
					return false;*/
		}

}



