package com.demo.dao;

import com.demo.pojo.Login;

public interface LoginDAO {
	public  boolean isValidUser(Login login);
	
	

}
