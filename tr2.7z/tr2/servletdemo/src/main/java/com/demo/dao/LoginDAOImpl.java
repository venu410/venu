package com.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demo.pojo.Login;

public class LoginDAOImpl implements LoginDAO{


	

	
	
	
public boolean isValidUser(Login login) {
		
		boolean flag=false;
		String sql="select * from loginuser where username=? and userpwd=?";
		try {
			PreparedStatement pst=getSQLConnection().prepareStatement(sql);
			
			pst.setString(1, login.getUserName());
			pst.setString(2, login.getUserPwd());
			
			ResultSet rs=pst.executeQuery();
			if(rs.next())
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}

	
	public Connection getSQLConnection(){
		Connection conn=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","India123");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}


	

}
