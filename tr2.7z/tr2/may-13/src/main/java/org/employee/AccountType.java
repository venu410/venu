package org.employee;

public enum AccountType {
	SAVINGS,CURRENT,SALARY;
}
