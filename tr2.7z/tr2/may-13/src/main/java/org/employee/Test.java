package org.employee;


	public class Test implements TestA{
		public static void main(String[] args) {
		System.out.println(new TestA() {
		public String toString() { return "test"; }
		});
		}
		
		
	}


