package org.employee;

import java.util.Scanner;

public class UserInteraction {

	 long accountNo;
	 String accountName;
	 String accountType;
	 String openDate;
	 String address;
	 Scanner sc=new Scanner(System.in);
	
	 public void getAccountDetails()
	 {
		
		// choice=sc.nextInt();
		 System.out.println("enter account no");
		 accountNo=sc.nextLong();
		 System.out.println("enter account name");
		 accountName=sc.next();
		 System.out.println("enter account type");
		 accountType=sc.next();
		 System.out.println("enter open date");
		 openDate=sc.next();
		 System.out.println("enter adress");
		 address=sc.next();
			
		 }
		 {
			 
		 }
		 
	 }
	 
	

