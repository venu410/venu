package org.employee;


	interface TestA { String toString(); }
	
