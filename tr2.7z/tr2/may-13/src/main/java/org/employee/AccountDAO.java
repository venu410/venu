
package org.employee;

public interface AccountDAO {
	public void createAccount();
	public void updateAccount(Account acname,Account acAmount);
	public void readAccountname(Account acnum,Account acName);
	public void deleteAccount(Account acnum);
	public void viewAllAccount(Account acnum,Account acName,Account acType,Account opendate,Account amount);
	public void exit();

}
