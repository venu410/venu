package org.employee;

public class AccountDAOImplement implements AccountDAO {

	public void createAccount() {
		// TODO Auto-generated method stub
		
	}

	public void updateAccount(Account acname, Account acAmount) {
		// TODO Auto-generated method stub
		
	}

	public void readAccountname(Account acnum, Account acName) {
		// TODO Auto-generated method stub
		
	}

	public void deleteAccount(Account acnum) {
		// TODO Auto-generated method stub
		
	}

	public void viewAllAccount(Account acnum, Account acName, Account acType, Account opendate, Account amount) {
		// TODO Auto-generated method stub
		
	}

	public void exit() {
		// TODO Auto-generated method stub
		
	}

}
