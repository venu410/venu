package org.programs;


	public class Test2 {
		public abstract class Circle extends Shape {
			private int radius;
			}
	}



