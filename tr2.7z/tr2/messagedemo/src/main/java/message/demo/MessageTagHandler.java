package message.demo;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class MessageTagHandler extends SimpleTagSupport{
	private String name;
	
	
	public void setName(String name)
	{
		this.name=name;
	}
	public void doTag() throws JspException, IOException 
	{
		JspWriter out=getJspContext().getOut();
		
		StringWriter str=new StringWriter();
		getJspBody().invoke(str);
		
		
		out.println("<h1>"+name+" "+str+"</h1>");
	}

}
