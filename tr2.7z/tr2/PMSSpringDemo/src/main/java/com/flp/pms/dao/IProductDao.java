package com.flp.pms.dao;

import java.util.List;
import java.util.Map;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public interface IProductDao {
	
	public void createProduct(Product product);

	public List<Category> getAllCategory();

	public List<SubCategory> getAllSubCategory();

	public List<Supplier> getAllSuppliers();

	public List<Discount> getAllDiscounts();

	public void addProduct(Product product);

	public Map<Integer, Product> getAllProducts();
	public List<Product> getAllProducts1();
	public void updateProductName(Product product,String productName);
	public void updateProductMaxRetailPrice(Product product,double max_price);
	public void updateProductExpiryDate(Product product, java.util.Date expiryDate);
	public void updateProductRating(Product product, float rating);

	public void updateProductCategory(Product product, Category category);
	public void deleteProduct(int productId);
	
}
