package org.file;

import java.io.File;
import java.util.Scanner;

public class Student {
	@SuppressWarnings("unused")
	private String sname;
	@SuppressWarnings("unused")
	private int regno;
	@SuppressWarnings("unused")
	private double fees;
	@SuppressWarnings("unused")
	private char gender;
	@SuppressWarnings("unused")
	private float marks;
	Scanner scan=new Scanner(System.in);
	File file=null;
	public void studentDetails()
	{
		System.out.println("1.enter student details");
		System.out.println("2.display student details");
		System.out.println("enter student name");
		sname=scan.next();
		System.out.println("enter student regno");
		regno=scan.nextInt();
		System.out.println("enter fee details");
		fees=scan.nextDouble();
		System.out.println("enter gender details");
		gender=(char) scan.nextInt();
		
	}
	

}
