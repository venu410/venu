package org.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileCopy {
	File file1=null;
	File file2=null;
	FileReader fr=null;
	FileWriter fw=null;
	public void copyFile()
	{
		file1=new File("D:\\kumar\\may-12-assignment\\src\\test\\java\\file1.txt");
		file2=new File("D:\\kumar\\may-12-assignment\\src\\test\\java\\file2.txt");
		try {
			fr=new FileReader(file1);
			fw=new FileWriter(file2);
			long size=file1.length();
			while(size>0)
			{
				int ch=fr.read();
				fw.write((char)ch);
				System.out.print((char)ch);
				size--;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				fr.close();
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
}
}


