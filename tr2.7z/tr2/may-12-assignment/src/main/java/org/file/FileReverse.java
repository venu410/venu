package org.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReverse {
	File file1=null;
	File file2=null;
	
	public void reverseFile()
	{
		File file=new File("D:\\kumar\\may-12-assignment\\src\\test\\java\\file1.txt");
		File f=new File("D:\\kumar\\may-12-assignment\\src\\test\\java\\file2.txt");
		FileReader fread=null;
		FileWriter fwrite=null;

try{
			fread=new FileReader(file);
			fwrite=new FileWriter(f);
			char[] ch=new char[100];
			
			fread.read(ch);
			String str=new String(ch);
			for(int i=str.length()-1;i>=0;i--)
			{
			 fwrite.write(str.charAt(i));
			}
			fwrite.flush();

}catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}catch (IOException e) {
			
			e.printStackTrace();
		}finally{
			try {
				fread.close();
				fwrite.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
		}

			
		
		
	}

