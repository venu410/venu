package org.file;

public class MainReverse {

	public static void main(String[] args) {
		FileReverse fr=new FileReverse();
		fr.reverseFile();

	}

}
