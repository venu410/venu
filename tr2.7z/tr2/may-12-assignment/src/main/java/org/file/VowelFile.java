package org.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class VowelFile {
	File file1=null;
	FileReader fr=null;
	int a,e,i,o,u;
	public void fileVowel()
	{
		file1=new File("D:\\kumar\\may-12-assignment\\src\\test\\java\\file1.txt");
		try {
		fr=new FileReader(file1);
		long size=file1.length();
		while(size>0)
		{
			int ch=fr.read();
			char c=(char)ch;
			switch(Character.toUpperCase(c))
			{
			case 'A':
				a++;
				break;
			case 'E':
				e++;
				break;
			case 'I':
				i++;
				break;
			case 'O':
				o++;
				break;
			case 'U':
				u++;
				break;
			
			
			}
			size--;
			
		}
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public void printVowels()
	{
		System.out.println("no of a's ="+ a);
		System.out.println("no of e's ="+ e);
		System.out.println("no of i's ="+ i);
		System.out.println("no of o's ="+ o);
		System.out.println("no of u's ="+ u);
	}
	

}
