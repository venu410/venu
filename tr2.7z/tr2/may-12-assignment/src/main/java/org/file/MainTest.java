package org.file;

public class MainTest {

	public static void main(String[] args) {
		FileCopy copy=new FileCopy();
		copy.copyFile();
	}

}
