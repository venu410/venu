package org.assignment;

import java.util.Scanner;

public class Student {
	private String sname;
	private int snumber;
	int arr[]=new int[10];
	public void studentDetails()
	{
		@SuppressWarnings("resource")
		Scanner scan=new Scanner(System.in);
		System.out.println("enter student name");
		sname=scan.next();
		System.out.println("enter student rollnumber");
		snumber=scan.nextInt();
		
	}
	public void printStudentDetails() 
	{
		
		for(int i=0;i<=arr.length-1;i++)
		{
			System.out.println(""+arr[i]);
			System.out.println("student roll number is:"+snumber);
			System.out.println("student name is:"+sname);
		}
	}

}
