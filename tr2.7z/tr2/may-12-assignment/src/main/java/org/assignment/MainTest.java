package org.assignment;

public class MainTest {

	public static void main(String[] args) {
		Student student=new Student();
		student.studentDetails();
		student.printStudentDetails();

	}

}
