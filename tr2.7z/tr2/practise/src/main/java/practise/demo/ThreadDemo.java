package practise.demo;

public class ThreadDemo extends Thread {
	int j=10;

	synchronized public void  run() {

		for(int i=1;i<=10;i++)
			System.out.println(i);
	}
	public void print(){
	while(j>8)
	{
		System.out.println(j--);
	}
	}

	public static void main(String[] args) {
		ThreadDemo demo=new ThreadDemo();
		demo.start();
		demo.print();
		

	}

}
