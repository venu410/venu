package programs.demo;

import java.util.Scanner;

public class MonthlySalaryEmployee extends Employee{
float no_of_days;
float sal_per_day;
@Override
public double calculateSalary() {
	Scanner scan=new Scanner(System.in);
	System.out.println("enter no of days");
	no_of_days=scan.nextFloat();
	System.out.println("enter salary per day");
	sal_per_day=scan.nextFloat();
	//scan.close();
	return salary=(no_of_days*sal_per_day);
}

}
