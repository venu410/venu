package programs.demo;

import java.util.Scanner;

public abstract class Employee {
	private int emp_Id;
	private String firstName,lastName;
	double salary;
	public void getEmployeeDetails()
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("enter employee_Id : ");
		emp_Id=scan.nextInt();
		System.out.println("enter FirstName : ");
		firstName=scan.next();
		System.out.println("enter LastName : ");
		lastName=scan.next();
		
		//scan.close();
			
	}
	public void printEmployeeDetails(){
		System.out.println("\nEmployee_id is: "+emp_Id+"\nEmployee FirstName is :"+firstName+"\nemployee lastName is :"+lastName);
		System.out.println("employee salary :"+salary);		
	}
	public abstract double calculateSalary();
	

}
