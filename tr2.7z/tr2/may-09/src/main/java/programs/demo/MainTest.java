package programs.demo;

import java.util.Scanner;

public class MainTest {

		public static void main(String[] args) {
		Employee emp=null;
		Scanner scan=new Scanner(System.in);
		System.out.println("1.Enter weekly salary:");
		System.out.println("2.Enter monthly salary:");
		System.out.println("enter choice");
		int choice=scan.nextInt();
		if(choice==1){
			emp=new WeeklyEmployeeSalary();
		}
		else if(choice==2){
			emp=new MonthlySalaryEmployee();
		}
		else{
			System.out.println("Invalid details");
		System.exit(0);
		}
		emp.getEmployeeDetails();
		emp.calculateSalary();
		emp.printEmployeeDetails();

	}

}
