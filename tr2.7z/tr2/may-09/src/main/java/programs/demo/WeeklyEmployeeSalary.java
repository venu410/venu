package programs.demo;

import java.util.Scanner;

public class WeeklyEmployeeSalary extends Employee{
	float no_of_hours;
	float wages_per_hour;

	@Override
	public double calculateSalary() {
		Scanner scan=new Scanner(System.in);
		System.out.println("no of hours");
		no_of_hours=scan.nextFloat();
		System.out.println("wages per day");
		wages_per_hour=scan.nextFloat();
		//scan.close();
			
		return salary=(no_of_hours*wages_per_hour);
		
	}

}
