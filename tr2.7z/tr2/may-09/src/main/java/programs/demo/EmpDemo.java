package programs.demo;

public class EmpDemo {

	public static void main(String[] args) {
		Emp emp1=new Emp(100,"venu","kumar",1234.98);
		Emp emp2=new Emp(100,"venu","kumar",1234.98);
		//emp1=emp2;
		System.out.println(emp1.equals(emp2));
		System.out.println(emp1==emp2);

	}

}
