package programs.demo;

public class TestClass {

	public static void main(String[] args) {
		StringBuffer str=new StringBuffer("Tom");
		str.append("welcome to capgemini pvt ltd");
		System.out.println("length:"+str.length());
		System.out.println("capacity:"+str.capacity());

	}

}
