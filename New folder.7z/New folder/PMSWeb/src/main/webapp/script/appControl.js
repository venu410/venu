app.controller("mycontroller",function($scope,$http){
	$scope.getCategories=function(){
		var url="http://localhost:8080/PMSWeb/ProductServlet?action=category";
		$http.get(url)
					.success(function(response){
						$scope.categories=response;
					})
					.error(function(msg){
						$scope.categories=msg;
					});
	
	};
	$scope.getSubCategories=function(){
		var url="http://localhost:8080/PMSWeb/ProductServlet?action=subcategory";
		$http.get(url)
					.success(function(response){
						$scope.subCategories=response;
					})
					.error(function(msg){
						$scope.subCategories=msg;
					});
	
	};
	
	$scope.getSupplier=function(){
		var url="http://localhost:8080/PMSWeb/ProductServlet?action=supplier";
		$http.get(url)
					.success(function(response){
						$scope.supplier=response;
					})
					.error(function(msg){
						$scope.supplier=msg;
					});
	
	};
	$scope.getDiscount=function(){
		var url="http://localhost:8080/PMSWeb/ProductServlet?action=discount";
		$http.get(url)
					.success(function(response){
						$scope.discount=response;
					})
					.error(function(msg){
						$scope.discount=msg;
					});
	
	};
	$scope.getallproductlist=function(){
		var url="http://localhost:8080/PMSWeb/ProductServlet?action=product";
		$http.get(url)
					.success(function(response){
						$scope.ListofProduct=response;
					})
					.error(function(msg){
						$scope.ListofProduct=msg;
					});
	
	};
});