package org.cap.demo;

import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class MainClass {

	public static void main(String[] args) {
		
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Customer.class);
		config.configure();
		
		//To Recreate Schema everyTime
		new SchemaExport(config).create(true, true);
		
		
		SessionFactory sessfactory=config.buildSessionFactory();
		
		//Default session
		//sessfactory.getCurrentSession();
		
		Customer customer=new Customer(1001, "Annie", 23000);
		
		Session session=sessfactory.openSession();
		org.hibernate.Transaction trans= session.beginTransaction();
		session.save(customer);
		
		trans.commit();
		session.close();

	}

}
