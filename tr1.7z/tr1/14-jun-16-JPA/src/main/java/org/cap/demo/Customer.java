package org.cap.demo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	
	@Id
	private int custId;
	private String custName;
	private double regFees;
	
	public Customer(){}
	
	public Customer(int custId, String custName, double regFees) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.regFees = regFees;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public double getRegFees() {
		return regFees;
	}
	public void setRegFees(double regFees) {
		this.regFees = regFees;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", regFees=" + regFees + "]";
	}
	
	

}
