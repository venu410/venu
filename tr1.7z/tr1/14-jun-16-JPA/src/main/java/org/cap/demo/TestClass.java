package org.cap.demo;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;



public class TestClass {

	public static void main(String[] args) {
		
		AnnotationConfiguration configuration=new AnnotationConfiguration();
		
		configuration.addAnnotatedClass(Employee.class);
		
		configuration.configure();
		int choice;
		Scanner scanner=null;
		SessionFactory factory=null;
		Session session=null;
		
		Date dob=null;
		Date doj=null;
		do {
			System.out.println("1.Create ");
			System.out.println("2.read");
			System.out.println("3.delete ");
			System.out.println("4.update");
			System.out.println("5.ListAll ");
			System.out.println("6.Exit");
			System.out.println("enter your option");
			scanner=new Scanner(System.in);
			choice = scanner.nextInt();
			switch (choice) {
	
		
		case 1:
			scanner=new Scanner(System.in);
			System.out.println("enter employee firstname");
			String firstName=scanner.next();
			System.out.println("enter employee lasttname");
			String lastName=scanner.next();
			System.out.println("enter employee salary");
			double salary=scanner.nextDouble();	
			
			System.out.println("enter employee dob-dd-mmm-yyyy");
			String date=scanner.next();
			
			System.out.println("enter employee doj-dd-mmm-yyyy");
			String date1=scanner.next();
				
					dob=new Date(date);
					doj=new Date(date1);
				
			System.out.println("enter employee email");
			String email=scanner.next();
				
			
			factory=configuration.buildSessionFactory();
			session=factory.openSession();
			session.getTransaction().begin();
			
			Employee employee=new Employee(firstName, lastName, salary, new java.sql.Date(dob.getTime()) ,new java.sql.Date(doj.getTime()) , email);

			session.save(employee);
			
			session.getTransaction().commit();
			
			session.close();
			
			
			break;
			
		case 2:
			scanner=new Scanner(System.in);
			System.out.println("enter employee id");
			int empID=scanner.nextInt();
			factory=configuration.buildSessionFactory();
			session=factory.openSession();
			session.getTransaction().begin();
			
			String hql="from Employee where empId=empID";
			
			Query query= session.createQuery(hql);
			
			List<Employee> employees= query.list();
			for(Employee emp:employees)
				System.out.println(emp);
			
			
			session.getTransaction().commit();
			
			session.close();
			
			
			break;
			
		case 3:
			scanner=new Scanner(System.in);
			System.out.println("enter employee id");
			int emplID=scanner.nextInt();
			factory=configuration.buildSessionFactory();
			session=factory.openSession();
			session.getTransaction().begin();
			
			String hql1="delete from Employee where empId=:emplID";
			
			Query query1= session.createQuery(hql1);
			
			List<Employee> employees1= query1.list();
			for(Employee emp:employees1)
				System.out.println(emp);
			
			
			session.getTransaction().commit();
			
			session.close();
			
			break;
		case 4:
			break;
			
		case 5:
			factory=configuration.buildSessionFactory();
			session=factory.openSession();
			session.getTransaction().begin();
			
			String qry="from Employee";
			
			Query query5= session.createQuery(qry);
			List<Employee> employe= query5.list();
			for(Employee emp:employe)
				System.out.println(emp);
			//session.save(employee);
			
			session.getTransaction().commit();
			
			session.close();
			

			break;
		case 6:
			
			System.exit(0);
		}
			
		
		
		} while (choice<0);
		
		
		}

}
