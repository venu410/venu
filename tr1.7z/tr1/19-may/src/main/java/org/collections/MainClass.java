package org.collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class MainClass {

	public static void main(String[] args) {
		Employee ad1=new Employee(1,"jock","jerry",12000);
		Employee ad2=new Employee(2,"tom","jerry",17000);
		Employee ad3=new Employee(3,"rock","star",16000);
		Employee ad4=new Employee(4,"merry","kiran",72000);
		Employee ad5=new Employee(5,"krish","ry",92000);
		Employee ad6=new Employee(2,"tom","jerry",17000);
		Employee ad7=new Employee(4,"merry","kiran",72000);
		//HashSet<Employee> demo=new HashSet<>();
		LinkedHashSet<Employee> demo=new LinkedHashSet<>();
		demo.add(ad1);
		demo.add(ad2);
		demo.add(ad3);
		demo.add(ad4);
		demo.add(ad5);
		demo.add(ad6);
		demo.add(ad7);
		Iterator<Employee> hs=demo.iterator();
		while(hs.hasNext())
		{
			System.out.println(hs.next());
		}
		

	}

}
