package org.collections;

public class Address {
	private int doorNumber;
	private String streetname,city,state;
	
	public Address() {
		
	}

	public Address(int doorNumber, String streetname, String city, String state) {
		super();
		this.doorNumber = doorNumber;
		this.streetname = streetname;
		this.city = city;
		this.state = state;
	}

	public int getDoorNumber() {
		return doorNumber;
	}

	public void setDoorNumber(int doorNumber) {
		this.doorNumber = doorNumber;
	}

	public String getStreetname() {
		return streetname;
	}

	public void setStreetname(String streetname) {
		this.streetname = streetname;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "Address [doorNumber=" + doorNumber + ", streetname=" + streetname + ", city=" + city + ", state="
				+ state + "]";
	}
	

}
