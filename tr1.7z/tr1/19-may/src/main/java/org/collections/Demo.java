package org.collections;

import java.util.ArrayList;
import java.util.ListIterator;

public class Demo {
	public static void main(String[] args)
	{
		ArrayList<Integer> al=new ArrayList<>();
		al.add(123);
		al.add(null);
		al.add(12);
		al.add(43);
		//al.add(2,10);
		
		ArrayList<Integer> al1=new ArrayList<>();
		al1.add(12);
		al1.add(15);
		al1.add(3);
		al.contains(al1);
		
		
		
		ListIterator<Integer> li=al.listIterator();
		while(li.hasNext())
		{
			Integer num=li.next();
			System.out.println(num);
		}
		}
	}


