package org.collections;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;


public class OrderBy {

	public static void main(String[] args) {
		SimpleDateFormat adf=new SimpleDateFormat("dd/mmm/yyyy");
		Date d1=null,d2=null,d3=null;
		
		Address add=new Address(1-2,"little","Hyderabad","telangana");
		Address add1=new Address(1-3,"s.p.colony","Vijayawada","Andhra");
		Address add2=new Address(1-6,"tr street","karnool","Chennai");
		
		try {
			String str1="21/may/2016";
			
			d1=adf.parse(str1);
			String str2="21/may/2016";
			
			d2=adf.parse(str2);
			String str3="21/may/2016";
			
			d3=adf.parse(str3);
				
			} catch (ParseException e) {
				
				e.printStackTrace();
			}
		
		//Account ac=new Account(123528,"Rama","Savings",,25000.00,add);
	//	Account ac1=new Account(256397,"Laxmana","Current",d2,65540.00,add1);
		//Account ac2=new Account(5698123,"Sita","Savings",d3,467356.00,add2);
		
		
		ArrayList<Account> al=new ArrayList<>();
		//al.addAll(add1);
		//al.add(ac1);
	//	al.add(ac2);
		Iterator<Account> itr=al.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		

	}

}
