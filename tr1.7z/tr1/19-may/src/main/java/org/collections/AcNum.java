package org.collections;

import java.util.Comparator;

public class AcNum implements Comparator<Account>{

	@Override
	public int compare(Account o1, Account o2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
