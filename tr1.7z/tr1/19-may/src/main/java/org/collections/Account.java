package org.collections;

import java.io.Serializable;
import java.util.Date;

public class Account implements Serializable{
	private long accountNumber;
	private String accountName;
	private String accountType;
	private Date openDate;
	private double salary;
	private Address address;
	//public Date simpledateformat
	public Account() {
		
	}
	
	public Account(long accountNumber, String accountName, String accountType, Date openDate, double salary,
			Address address) {
		super();
		this.accountNumber = accountNumber;
		this.accountName = accountName;
		this.accountType = accountType;
		this.openDate = openDate;
		this.salary = salary;
		this.address = address;
	}
	

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}


	
	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountName=" + accountName + ", accountType="
				+ accountType + ", openDate=" + openDate + ", salary=" + salary + ", address=" + address + "]";
	}
	
	
}
	
