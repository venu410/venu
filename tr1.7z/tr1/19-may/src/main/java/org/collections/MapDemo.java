package org.collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		Map<Integer,String> map=new HashMap<>();
		map.put(1,"venu");
		map.put(20,"kumar");
		map.put(23,"null");
		map.put(12,"vijay");
		Set<Integer> value=map.keySet();
		System.out.println(value);
		Iterator<Integer> itr=value.iterator();
		System.out.println(map.entrySet());
		//System.out.println(map);
		System.out.println(map.remove(1));
		/*while(itr.hasNext())
		{
			int num=itr.next();
			System.out.println(num);
			
		}
		System.out.print(map.get(value));*/

	}

}
