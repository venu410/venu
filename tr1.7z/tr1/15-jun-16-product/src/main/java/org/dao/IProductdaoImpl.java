package org.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import org.pojo.Category;
import org.pojo.Product;

public class IProductdaoImpl implements IProductDAO{

	@Override
	public Connection getMySQlConnection() {
		Connection conn = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/product", "root", "India123");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return conn;
	}

	@Override
	public List<Category> getAllCategories() {
		Connection connection=null;
		PreparedStatement ps=null;
		List<Category> categories=new ArrayList<>();
		try {
			connection=getMySQlConnection();
			 ps=connection.prepareStatement("select *from category");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Category category=new Category();
				category.setCategory_id(rs.getInt(1));
				category.setCategory_name(rs.getString(2));
				category.setDescription(rs.getString(3));
				categories.add(category);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return categories;
	}

	@Override
	public List<Product> getAllProducts() {
		List<Product> products=new ArrayList<>();
		Connection connection=null;
		PreparedStatement ps=null;
		connection=getMySQlConnection();
		try {
			ps=connection.prepareStatement("select *from product");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Product product=new Product();
				product.setProduct_id(rs.getInt(1));
				product.setProduct_name(rs.getString(2));
				product.setPrice(rs.getDouble(3));
				int categoryId=rs.getInt(4);
				List<Category> categories=getAllCategories();
				for(Category category:categories){
					if(category.getCategory_id()==categoryId){
						product.setCategory(category);
						break;
					}
				}
				product.setQuantity(rs.getInt(5));
				products.add(product);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
		}
		
		return products;
	}

	@Override
	public void addProduct(Product product) {
		Connection connection=null;
		PreparedStatement ps=null;
		connection=getMySQlConnection();
		try {
			ps=connection.prepareStatement("insert into product(productName,price,category_Id,quantity)values(?,?,?,?)");
		    
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}








		
	
	
	


