package org.dao;

import java.sql.Connection;
import java.util.List;


import org.pojo.Category;
import org.pojo.Product;

public interface IProductDAO {
	
	public Connection getMySQlConnection();
	public  List<Category> getAllCategories();
	public  List<Product> getAllProducts();
	public void addProduct(Product product);
	
}
