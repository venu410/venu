package com.org.demo;

public class Customer {
	private int cust_Id;
	private String cust_Name;
	private long cust_No;
	
	public Customer(){}
	
	
	public Customer(int cust_Id, String cust_Name, long cust_No) {
		super();
		this.cust_Id = cust_Id;
		this.cust_Name = cust_Name;
		this.cust_No = cust_No;
		
		
		
	}


	public int getCust_Id() {
		return cust_Id;
	}


	public void setCust_Id(int cust_Id) {
		this.cust_Id = cust_Id;
	}


	public String getCust_Name() {
		return cust_Name;
	}


	public void setCust_Name(String cust_Name) {
		this.cust_Name = cust_Name;
	}


	public long getCust_No() {
		return cust_No;
	}


	public void setCust_No(long cust_No) {
		this.cust_No = cust_No;
	}


	@Override
	public String toString() {
		return "Customer [cust_Id=" + cust_Id + ", cust_Name=" + cust_Name + ", cust_No=" + cust_No + "]";
	}
	

}
