package org.employee;

public class MainClass {

	
	public static void main(String[] args) {
		
		UserInteraction interaction=new UserInteraction();
		Employee emp= null;
				try {
					emp=interaction.getEmployee();
				} catch (InvalidSalaryException e) {
					//System.out.println("enter correct salary");
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvalidDobException ex) {
					ex.printStackTrace();
				}
		
		System.out.println(emp);
		
	}


}


