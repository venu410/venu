package org.employee;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class DateOfBirth {
	public void calDateOfBirth(){
	Calendar cal=new GregorianCalendar();
	Scanner scan=new Scanner(System.in);
	System.out.println("enter date of birth");
	SimpleDateFormat smp=new SimpleDateFormat("dd/mmm/yyyy");
	
	}
	

}
