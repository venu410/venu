package org.employee;
import java.util.Scanner;
import java.util.Date;


public class UserInteraction {

	public Employee getEmployee()throws InvalidSalaryException, InvalidSalaryException {
		Employee employee=new Employee();
		int employeeId,age;
		double empSalary;
		boolean flag=false;
		String eid,empKinId;
		String firstName,email,lastName;
		Scanner sc=new Scanner(System.in);
		
		
		//Validate Employee Id
		do{
		System.out.println("Enter Employee Id:");
		eid=sc.next();
		flag=Validate.isValidEmployeeId(eid);
			if(!flag)
				System.out.println("INvalid EmployeeId! ID should be 5 digit!");
		
		}while(!flag);

		employee.setEmpId(Integer.parseInt(eid));
		
		
				//Validate Employee KinId
				do{
				System.out.println("Enter Employee KinId:");
				empKinId=sc.next();
				flag=Validate.isValidKinId(empKinId);
					if(!flag)
						System.out.println("Invalid KinId!");
				
				}while(!flag);

				employee.setKinId(empKinId);
				
				
				//validate Employee age
				do
				{
					System.out.println("Enter age:");
					age = sc.nextInt();
					flag=Validate.isValidAge(""+age);
					if(!flag || age<=18)
					System.out.println("Enter valid age");
				}while(!flag || age<=18);
					employee.setAge(age);
				
					//validate Employee first name
					do{
						System.out.println("Enter Employee First name:");
						firstName=sc.next();
						flag=Validate.isValidFirstName(firstName);
							if(!flag)
								System.out.println("Invalid FirstName!");
						
						}while(!flag);

						employee.setFirstName(firstName);
					
					//validate Employee last name
						do{
							System.out.println("Enter Employee Last name:");
							lastName=sc.next();
							flag=Validate.isValidFirstName(firstName);
								if(!flag)
									System.out.println("Invalid LastName!");
							
							}while(!flag);

							employee.setLastName(lastName);;
						
						//validate Employee salary
						//try{
						do
							{
						
							System.out.println("Enter Salary:");
							empSalary = sc.nextDouble();
							flag=Validate.isValidEmployeeSalary(""+empSalary);
							if(!flag && (empSalary<2000 || empSalary>500000))
							//throw new InvalidSalaryException();
								System.out.println("Enter valid Salary");
						
							}while(!flag && (empSalary<2000 || empSalary>500000));
							employee.setSalary(empSalary);
							/*catch(InvalidSalaryException e){
								System.out.println("Error:"+e.getMessage());
								//e.printStackTrace();
								} */
						
							
						//validate Email
							do{
								System.out.println("Enter Email:");
								email=sc.next();
								flag=Validate.isValidEmail(email);
									if(!flag)
										System.out.println("Invalid email!");
								
								}while(!flag);

								employee.setEmail(email);
								
								System.out.println("Enter Date of Birth:");
								employee.setEmpDOB(getDateValue());

								System.out.println("Enter Date of Joining:");
								employee.setEmpDOJ(getDateValue());
								
						//validate address		
						
						
								
							
		return employee;
	}



	//validate date
	public Date getDateValue(){
	String empDob;
	Scanner sc=new Scanner(System.in);
	boolean flag=false;
	
	do{
	
	empDob=sc.next();
	flag=Validate.isValidDate(empDob);
		if(!flag)
			System.out.println("Invalid Date Format! (dd-MMM-yyyy)");
	
	}while(!flag);
	
	
	Date empdb=new Date(empDob);
	
	return empdb;
}
}