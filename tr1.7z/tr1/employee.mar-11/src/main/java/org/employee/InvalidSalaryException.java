package org.employee;
public class InvalidSalaryException extends Exception {

		@Override
		public String getMessage() {
			return "Error In Salary!";
		}
	}



