package org.employee;


public class InvalidDobException extends RuntimeException {

		@Override
		public String getMessage() {
			return "Error In date of birth!";
		}
	}



