package org.employee;

public class Validate {
	public static boolean isValidEmployeeId(String empId){
		return empId.matches("\\d{5}");
	}
	
	public static boolean isValidKinId(String kinid){
		return kinid.matches("\\d{5}_(FS|TS|IN|fs|ts|in)");
	}
	
	public static boolean isValidAge(String age){
		return age.matches("\\d{2}");
	}
	
	public static boolean isValidFirstName(String firstName){
		return firstName.matches("[A-Z]{1}[a-z]*");
	}
	
	public static boolean isValidLastName(String lastName){
		return lastName.matches("[A-Z]");
	}
	
	public static boolean isValidEmployeeSalary(String salary){
		return salary.matches("\\d");
	}
	
	public static boolean isValidEmail(String email){
		return email.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
	}
	
	
	public static boolean isValidDate(String empDob){
		return empDob.matches("[0-3][0-9]-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-"
				+ "[12][7890]\\d{2}");
	}


}
