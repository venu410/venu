package org.employee;
import java.util.Date;
public class Employee {

		private int empId,age;
		private String age1;
		public String getAge1() {
			return age1;
		}
		public void setAge1(String age1) {
			this.age1 = age1;
		}
		private String kinId, firstName, lastName;
		private String address,email;
		private Date empDOB, empDOJ;
		
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		private double salary;
		public int getEmpId() {
			return empId;
		}
		public void setEmpId(int empId) {
			this.empId = empId;
		}
		
		public String getKinId() {
			return kinId;
		}
		public void setKinId(String kinId) {
			this.kinId = kinId;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public double getSalary() {
			return salary;
		}
		public void setSalary(double salary) {
			this.salary = salary;
		}
		public Date getEmpDOB() {
			return empDOB;
		}
		public void setEmpDOB(Date empDOB) {
			this.empDOB = empDOB;
		}
		public Date getEmpDOJ() {
			return empDOJ;
		}
		public void setEmpDOJ(Date empDOJ) {
			this.empDOJ = empDOJ;
		}
		
		@Override
		public String toString() {
			return "Employee [empId=" + empId + ", age=" + age + ", age1=" + age1 + ", kinId=" + kinId + ", firstName="
					+ firstName + ", lastName=" + lastName + ", address=" + address + ", email=" + email + ", empDOB="
					+ empDOB + ", empDOJ=" + empDOJ + ", salary=" + salary + "]";
		}
		
		
}



