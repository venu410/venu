package assignments.exception;

public class ArrayMain {

	public static void main(String[] args) {
		
		ArrayExPrint ap=new ArrayExPrint();
		ap.arrayException();
		

	}

}
