package assignments.exception;

public class ArrayException  {
	
	private int num;
	private String name;
	
	public ArrayException(int num, String name) {
		super();
		this.num = num;
		this.name = name;
	}
	

	@Override
	public String toString() {
		return "ArrayException [num=" + num + ", name=" + name + "]";
	}


	

}
