package assignments.exception;

import java.util.Scanner;

public class ArrayExPrint  {
	
	 void arrayException()
	{
		
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the value");
		int i=scan.nextInt();
		
		ArrayException str[]=new ArrayException[10];
		str[0]=new ArrayException(1,"tom");
		str[1]=new ArrayException(2,"pavi");
		str[2]=new ArrayException(3,"pree");
		str[3]=new ArrayException(4,"venu");
		str[4]=new ArrayException(5,"om");
		str[5]=new ArrayException(6,"omi");
		str[6]=new ArrayException(7,"jerry");
		str[7]=new ArrayException(8,"cat");
		str[8]=new ArrayException(9,"rat");
		str[9]=new ArrayException(10,"kitty");
		//str[10]=new ArrayException(11,"kitty");
		try{
		
			System.out.println(str[i]);
		}
			catch(ArrayIndexOutOfBoundsException e)
			{
				//System.out.println("catch");
				e.printStackTrace();
			}
		
		{
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
