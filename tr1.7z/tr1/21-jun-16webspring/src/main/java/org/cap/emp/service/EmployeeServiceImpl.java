package org.cap.emp.service;

import java.util.List;

import org.cap.emp.dao.EmployeeDao;
import org.cap.emp.dto.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeDao empDao;

	@Transactional
	public void saveEmployee(Employee employee) {
		empDao.saveEmployee(employee);
		
	}

	@Transactional
	public List<Employee> getAllEmployees() {
		
		return empDao.getAllEmployees();
	}

	@Transactional
	public void deleteEmployee(Integer employeeId) {
		empDao.deleteEmployee(employeeId);
		
	}

	@Override
	public void updateEmployee(Integer employeeId) {
		empDao.updateEmployee(employeeId);
		
	}

	

}
