package assignment.first;

public class WordMain {

	public static void main(String[] args) {
		Word word=new Word();
		word.getDigitalNumber();
		word.getWordFormat();

	}

}
