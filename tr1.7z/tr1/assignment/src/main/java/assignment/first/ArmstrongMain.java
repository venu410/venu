package assignment.first;

public class ArmstrongMain {

	public static void main(String[] args) {
		ArmstrongNumber an=new ArmstrongNumber();
		an.printArmstrongNumber();

	}

}
