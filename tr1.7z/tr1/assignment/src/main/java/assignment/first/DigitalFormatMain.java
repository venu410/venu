package assignment.first;

public class DigitalFormatMain {

	public static void main(String[] args) {
		DigitalFormat df=new DigitalFormat();
		df.digitalNumber();

	}

}
