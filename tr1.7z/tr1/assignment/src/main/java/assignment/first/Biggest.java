package assignment.first;

import java.util.Scanner;

public class Biggest {
	int a,b,c;

	public void getNumber(){
		Scanner scan=new Scanner(System.in);
		System.out.println("enter 1st number");
		a=scan.nextInt();	
		System.out.println("enter 2nd number");
		b=scan.nextInt();	
		System.out.println("enter 3rd number");
		c=scan.nextInt();
		scan.close();
	}
	public void printNumber()
	{
		if(a>b&&a>c)
		{
			System.out.println("The biggest number is:"+a);
		}
		else if(b>a&&b>c)
		{
			System.out.println("The biggest number is:"+b);
		}
		else
		{
			System.out.println("The biggest number is:"+c);
		}
		
	}	

}
