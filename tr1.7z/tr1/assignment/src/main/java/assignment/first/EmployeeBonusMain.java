package assignment.first;

public class EmployeeBonusMain {

	public static void main(String[] args) {
		EmployeeBonus eb=new EmployeeBonus();
		eb.getEmployeeDetails();
		eb.printEmployeeDetails();

	}

}
