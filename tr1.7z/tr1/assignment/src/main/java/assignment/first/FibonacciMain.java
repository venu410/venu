package assignment.first;

public class FibonacciMain {

	public static void main(String[] args) {
		FibonacciSeries fc=new FibonacciSeries();
		fc.printSeries();

	}

}
