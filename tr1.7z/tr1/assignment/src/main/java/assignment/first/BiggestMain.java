package assignment.first;

public class BiggestMain {

	public static void main(String[] args) {
		Biggest b=new Biggest();
		b.getNumber();
		b.printNumber();

	}

}
