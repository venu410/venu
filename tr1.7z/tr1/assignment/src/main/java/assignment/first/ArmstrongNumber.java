package assignment.first;

public class ArmstrongNumber {
	public void printArmstrongNumber(){
		int r,sum=0,n;
		System.out.println("Armstrong number from 1 to 1000 is:");
		for(int i=1;i<=1000;i++)
		{
			n=i;
			while(n>0)
			{
				r=n%10;
				sum=sum+(r*r*r);
				n=n/10;	
			}
			if(sum==i)
			{
				System.out.println(i);
			}
			sum=0;
		}

	}
}
