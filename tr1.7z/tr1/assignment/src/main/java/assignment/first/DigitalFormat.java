package assignment.first;

import java.util.Scanner;

public class DigitalFormat {
	public void digitalNumber()
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the number between 0 and 9");
		int n= scan.nextInt();
		int arr[][] = new int[5][5];
		switch(n){
		case 0:
			zero(arr);
			break;
		case 1:
			one(arr);
			break;
		case 2:
			two(arr);
			break;
		case 3:
			three(arr);
			break;
		case 4:
			four(arr);
			break;
		case 5:
			five(arr);
			break;
		case 6:
			six(arr);
			break;
		case 7:
			seven(arr);
			break;
		case 8:
			eight(arr);
			break;
		case 9:
			nine(arr);
			break;
		 default:System.out.println("wrong input");
		 
		 
		}
		scan.close();
	}
	private static void nine(int[][] arr) {
		for(int i=0;i<5;i++){
			for(int j=0;j<5;j++){
				if(i==0 || i==4 || (j==0 && i==1) || j==4 || i==2)
					System.out.print("* ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
	}
	private static void eight(int[][] arr) {
		for(int i=0;i<5;i++){
			for(int j=0;j<5;j++){
				if(i==0 || i==4 || j==0 || j==4 || i==2)
					System.out.print("* ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
	}

	private static void seven(int[][] arr) {
		for(int i=0;i<5;i++){
			for(int j=0;j<5;j++){
				if(i==0 || j==4)
					System.out.print("* ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
	}

	private static void six(int[][] arr) {
		for(int i=0;i<5;i++){
			for(int j=0;j<5;j++){
				if(i==0 || i==4 || i==2 || j==0  || (j==4 && i==3))
					System.out.print("* ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
	}

	private static void five(int[][] arr) {
		for(int i=0;i<5;i++){
			for(int j=0;j<5;j++){
				if(i==0 || i==4 || i==2 || (j==0 && i==1) || (j==4 && i==3))
					System.out.print("* ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
	}

	private static void four(int[][] arr) {
		for(int i=0;i<5;i++){
			for(int j=0;j<5;j++){
				if(i==2 || j==4 || (j==0 && i==0)  || (j==0 && i==1)  )
					System.out.print("* ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
	}

	private static void three(int[][] arr) {
		for(int i=0;i<5;i++){
			for(int j=0;j<5;j++){
				if(i==0 || i==4 || i==2 || j==4 )
					System.out.print("* ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
	}

	private static void two(int[][] arr) {
		for(int i=0;i<5;i++){
			for(int j=0;j<5;j++){
				if(i==0 || i==4 || i==2 || (j==4 && i==1) || (j==0 && i==3))
					System.out.print("* ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
	}

	private static void one(int[][] arr) {
		for(int i=0;i<5;i++){
			for(int j=0;j<5;j++){
				if(j==4)
					System.out.print("* ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
	}

	private static void zero(int[][] arr) {
		for(int i=0;i<5;i++){
			for(int j=0;j<5;j++){
				if(i==0 || i==4 || j==0 || j==4)
					System.out.print("* ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
	}
	

}

