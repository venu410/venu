package assignment.file.count;

public class BootClass {
	
		public static void main(String[] args) {
			
			
			BusinessClass b1 = new BusinessClass();
			b1.logic();
		

		}

}
