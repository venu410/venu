package assignment.file.copy;



	import java.io.File;
	import java.io.FileReader;
	import java.io.FileWriter;
	import java.util.Scanner;

	public class BusinessClass {

		Scanner sc = new Scanner(System.in);
		File file1 = new File("D:\\kumar\\assignment\\src\\test\\java\\file1.txt");
		File file2 = new File("D:\\kumar\\assignment\\src\\test\\java\\file2.txt");
		String content;
		FileReader fileReader = null;
		FileWriter fileWriter = null;
		char ch[];

		void logic() {
			try {
				// file1.createNewFile();
				System.out.println("Enter the content to  write in file1");
				content = sc.next();
				fileWriter = new FileWriter(file1);
				fileWriter.write(content);
				fileWriter.flush();
				fileWriter.close();
				System.out.println("the given content is sucessfully written in file 1 !!");
				// file2.createNewFile();

				fileReader = new FileReader(file1);
				ch = new char[(int) file1.length()];
				fileReader.read(ch);
				String str = new String(ch);

				fileWriter = new FileWriter(file2);
				fileWriter.write(str);
				fileWriter.flush();
				System.out.println("The content of file 1 is copied to file 2 !!");
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

}


