package assignment.file.bytestream;

	import java.io.DataInputStream;
	import java.io.DataOutputStream;
	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileOutputStream;
	import java.util.Scanner;

	public class BootClass {

		@SuppressWarnings({ "unused", "resource" })
		public static void main(String[] args) {
			int choice;
			Scanner sc = new Scanner(System.in);
			File file = new File("StudentDataBase.txt");
			FileOutputStream fileOutputStream = null;
			DataOutputStream dataOutputStream = null;
			FileInputStream fileInputStream = null;
			DataInputStream dataInputStream = null;
			Student student = new Student();
			try {
				file.createNewFile();
				fileOutputStream = new FileOutputStream(file,true);
				dataOutputStream = new DataOutputStream(fileOutputStream);
				

				for (;;) {
					System.out.println(
							"Enter your choice : \n1. To add student's details\n2.To view student's Details\n3.Exit");
					choice = sc.nextInt();
					switch (choice) {
					case 1:
						student.getDetails(dataOutputStream);
						break;
					case 2:
						student.printDetails(dataInputStream,file);
						break;
					case 3:
						System.exit(0);
						break;
					default:
						System.out.println("Enter the choice between 1-3:");
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
}


