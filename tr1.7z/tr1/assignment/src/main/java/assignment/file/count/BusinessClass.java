package assignment.file.count;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class BusinessClass {

		Scanner sc = new Scanner(System.in);
		File file = new File("D:\\kumar\\assignment\\src\\test\\java\\file1.txt");
		FileReader fileReader = null;
		char ch[];
		int fileSize;
		String str;
		int lineNo=1;
		void logic() {
			try {
				file.createNewFile();
				fileReader = new FileReader(file);
				ch = new char[(int) file.length()];
				fileReader.read(ch);
				str = new String(ch);
				String[] str1 = str.split(" ");
				System.out.println(str1.length + " words available in the file.");
				for(int q = 0;q<(int) file.length();q++)
				{
					if(ch[q]=='\n')
						lineNo++;
					
				}
				System.out.println(lineNo+" number of lines");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	
}