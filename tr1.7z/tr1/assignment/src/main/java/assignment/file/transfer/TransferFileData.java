package assignment.file.transfer;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class TransferFileData {
	

	public static void main(String[] args) {
			
	File file = new File("D:\\kumar\\assignment\\src\\test\\java\\file1.txt");
	File file1 = new File("D:\\kumar\\assignment\\src\\test\\java\\file2.txt");

	FileReader fileReader = null;
	FileWriter fileWriter = null;
	char ch[];
	String str;
			try

			{
				file1.createNewFile();
				file.createNewFile();
				fileReader = new FileReader(file);
				ch = new char[(int) file.length()];
				fileReader.read(ch);
				str = new String(ch);
				char ch1[] = str.toCharArray();
				fileReader.close();
				fileWriter = new FileWriter(file1);
				for (int i = ch1.length - 1; i >= 0; i--) {
					
					fileWriter.write(ch1[i]);
					
					
				}
				fileWriter.flush();
				

			} catch(

			Exception e)

			{
				e.printStackTrace();
			}
			

		}

}



