package assignment.file.bytestream;

	import java.io.*;

	import java.io.DataOutputStream;
	import java.io.File;
	import java.io.FileInputStream;
	import java.util.Scanner;

	public class Student {

		String studentName;
		int rollNumber;
		String gender;
		double mark1;
		double mark2;
		double mark3;
		Scanner sc = new Scanner(System.in);
		FileInputStream fileInputStream=null;
		void getDetails(DataOutputStream dataOutputStream)

		{
			try {

				System.out.println("Enter the student's name :");
				studentName = sc.next();
				// byte[] b = new byte[studentName.length()];
				// dataOutputStream.write(studentName.getBytes());
				dataOutputStream.writeUTF(studentName);
				System.out.println("Enter the student's roll number :");
				rollNumber = sc.nextInt();
				dataOutputStream.writeInt(rollNumber);
				System.out.println("Enter the student's gender :");
				gender = sc.next();
				// dataOutputStream.write(gender.getBytes());
				dataOutputStream.writeUTF(gender);
				System.out.println("Enter the student's mark1 :");
				mark1 = sc.nextDouble();
				dataOutputStream.writeDouble(mark1);
				System.out.println("Enter the student's mark2 :");
				mark2 = sc.nextDouble();
				dataOutputStream.writeDouble(mark2);
				System.out.println("Enter the student's mark3 :");
				mark3 = sc.nextDouble();
				dataOutputStream.writeDouble(mark3);
				dataOutputStream.flush();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		void printDetails(DataInputStream dataInputStream, File file) {
			try {
				fileInputStream = new FileInputStream(file);
				dataInputStream = new DataInputStream(fileInputStream);
				char ch[] = new char[(int)file.length()];
				System.out.println(
						"Name : " + "\t\trollnumber : " + "\tGender : " + "\tmarks1 : " + "\tMarks2 : " + "\tMarks3 : ");
				try {
					for (int i = 0;ch[i]!= -1 ; i++) {
						System.out.println(dataInputStream.readUTF() + "\t\t" + dataInputStream.readInt() + "\t\t"
								+ dataInputStream.readUTF() + "\t\t" + dataInputStream.readDouble() + "\t\t"
								+ dataInputStream.readDouble() + "\t\t" + dataInputStream.readDouble());
					}
					dataInputStream.close();
				} catch (Exception e) {
					//e.printStackTrace();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
}


