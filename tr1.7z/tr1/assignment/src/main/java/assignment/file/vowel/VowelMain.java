package assignment.file.vowel;

public class VowelMain {

	public static void main(String[] args) {
		VowelFile vf=new VowelFile();
		vf.fileVowel();
		vf.printVowels();

	}

}
