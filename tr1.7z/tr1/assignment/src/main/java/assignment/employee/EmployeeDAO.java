package assignment.employee;

public interface EmployeeDAO {
	public void create();
	public void viewAll();
	public void search(Employee eid);

}
