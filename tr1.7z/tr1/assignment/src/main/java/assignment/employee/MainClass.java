package assignment.employee;

public class MainClass {

	public static void main(String[] args) {
		UserInteraction ui=new UserInteraction();
		ui.getEmployeeDetails();

	}

}
