package assignment.employee;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class UserInteraction {
	Scanner scan=new Scanner(System.in);
	SimpleDateFormat sdf=new SimpleDateFormat("dd/mm/yyyy");
	Date dob,doj;
	int choice;
	public void getEmployeeDetails()
	{
		System.out.println("enter your choice");
		choice=scan.nextInt();
		do{
		System.out.println("1.Create Employee Details");
		System.out.println("2.View Employee Details");
		System.out.println("3.Search Employee Details");
		System.out.println("4.exit");
		switch(choice)
		{
		case 1:		
		System.out.println("enter employee id:");
		@SuppressWarnings("unused")
		int eid=scan.nextInt();
		System.out.println("enter first name");
		@SuppressWarnings("unused")
		String fName=scan.next();
		System.out.println("enter last name");
		@SuppressWarnings("unused")
		String lName=scan.next();
		System.out.println("enter date of birth");
		String str1=scan.next();
		System.out.println("enter date of joining");
		String str2=scan.next();
		try {
			dob=sdf.parse(str1);
			doj=sdf.parse(str2);
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		break;
		
		case 2:
			break;
		case 3:
			break;
		case 4:
			System.exit(0);
			break;
		}
		
	}while(choice!=0);
	
	}

}
	


