package assignment.employee;

public class EmployeeDAOImplementation implements EmployeeDAO{

	@Override
	public void create() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void viewAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void search(Employee eid) {
		// TODO Auto-generated method stub
		
	}

}
