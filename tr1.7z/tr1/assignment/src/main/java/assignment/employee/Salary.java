package assignment.employee;

public class Salary {
	private int noofdaysworked;
	private double salryperday;
	
	public Salary() {
		
	}

	public Salary(int noofdaysworked, double salryperday) {
		super();
		this.noofdaysworked = noofdaysworked;
		this.salryperday = salryperday;
	}

	public int getNoofdaysworked() {
		return noofdaysworked;
	}

	public void setNoofdaysworked(int noofdaysworked) {
		this.noofdaysworked = noofdaysworked;
	}

	public double getSalryperday() {
		return salryperday;
	}

	public void setSalryperday(double salryperday) {
		this.salryperday = salryperday;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + noofdaysworked;
		long temp;
		temp = Double.doubleToLongBits(salryperday);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Salary other = (Salary) obj;
		if (noofdaysworked != other.noofdaysworked)
			return false;
		if (Double.doubleToLongBits(salryperday) != Double.doubleToLongBits(other.salryperday))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Salary [noofdaysworked=" + noofdaysworked + ", salryperday=" + salryperday + "]";
	}
	
	

}
