package assignment.hashmap.employee;

public interface RepositoryDAO {
	
		boolean saveDetails(Employee employee, Salary salary);
		boolean view(UserInteraction userInterface);
		
		boolean search(int i);
	
}
