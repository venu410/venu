package assignment.hashmap.employee;

	import java.util.Scanner;

	public class BootClass {

		@SuppressWarnings("resource")
		public static void main(String[] args) {

			int choice;
			Scanner scanner = new Scanner(System.in);
			UserInteraction userInterface = new UserInteraction();
			RepositoryDAO repositoryDAO = new RepositoryDAOImpl();
			boolean bol;
			Employee employee;
			Salary salary;
			for (;;) {
				System.out.println("Enter your choice\n1.To Create\n2.View All\n3.Search\n4.To Exit");
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					employee = userInterface.createEmployeeObject();
					salary = userInterface.createSalaryObject();
					bol = repositoryDAO.saveDetails(employee, salary);
					if (bol)
						System.out.println("Employee ID already exsist...!!!");
					else
						System.out.println("Your account is added");
					break;
				case 2:
					repositoryDAO.view(userInterface);
					break;
				case 3:
					int i = userInterface.search();
					 bol = repositoryDAO.search(i);
					if (!bol)
						System.out.println("The entered employee ID does not exsist....!!!");
						
					
					break;
				case 4:
					System.exit(0);
				default:
					System.out.println("Pleae enter the choice 1 or 2 or 3.");
					break;
				}
			}
		}
}
