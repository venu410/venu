package assignment.hashmap.employee;

 
	import java.util.HashMap;
	import java.util.Iterator;
	import java.util.Set;

	public class RepositoryDAOImpl implements RepositoryDAO {

		HashMap<Employee, Salary> hashMap = new HashMap<Employee, Salary>();
		Set<Employee> keys;

		public boolean saveDetails(Employee employee, Salary salary) {

			boolean flag = false;
			keys = hashMap.keySet();

			Iterator<Employee> iterator = keys.iterator();
			while (iterator.hasNext()) {
				flag = (employee.getEmployeeId() == iterator.next().getEmployeeId());
			}
			if (flag)
				return flag;
			else {
				hashMap.put(employee, salary);
				return flag;
			}
		}

		public boolean view(UserInteraction userInterface) {

			keys = hashMap.keySet();
			userInterface.viewAll(hashMap, keys);
			return false;
		}

		
		
		public boolean search(int i) {

			boolean flag = false;
			keys = hashMap.keySet();

			Iterator<Employee> iterator = keys.iterator();
			while (iterator.hasNext()) {
				Employee emp = iterator.next();
				flag = (i == emp.getEmployeeId());
				if(flag)
				{System.out.println(emp+" "+hashMap.get(emp));break;}
			}
			
			
			return flag;
			
		}
}


