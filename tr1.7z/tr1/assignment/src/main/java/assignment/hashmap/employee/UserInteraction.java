package assignment.hashmap.employee;

	import java.util.Date;
	import java.util.HashMap;
	import java.util.Iterator;
	import java.util.Scanner;
	import java.util.Set;

	public class UserInteraction {
		Scanner scanner = new Scanner(System.in);
		int employeeId;
		String firstName;
		String lastName;
		Date dateOfBirth;
		Date dateOfJoining;
		int noOfDaysWorked;
		double salaryPerDay;

		Employee createEmployeeObject() {
			System.out.println("Enter the employee Id");
			employeeId = scanner.nextInt();
			System.out.println("Enter the employee's First Name");
			firstName = scanner.next();
			System.out.println("Enter the employee's Last Name");
			lastName = scanner.next();
			return new Employee(employeeId, firstName, lastName, new Date(), new Date());
		}

		Salary createSalaryObject() {
			
			System.out.println("Enter the number Of Days Worked");
			noOfDaysWorked = scanner.nextInt();
			System.out.println("Enter salary per day");
			salaryPerDay = scanner.nextDouble();
			return new Salary(noOfDaysWorked, salaryPerDay);
		}

		void viewAll(HashMap<Employee, Salary> hashMap, Set<Employee> keyes) {
			Iterator<Employee> iterator = keyes.iterator();
			while (iterator.hasNext()) {
				Employee employee = iterator.next();
				System.out.println(employee);
				System.out.println(hashMap.get(employee));
			}
		}
		
		
		int search()
		{
			
			System.out.println("Entr the employee id to search the employee details:");
			int i = scanner.nextInt();
			return i;
		}
}


