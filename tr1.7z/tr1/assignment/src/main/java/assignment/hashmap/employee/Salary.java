package assignment.hashmap.employee;


	public class Salary {

		private int noOfDaysWorked;
		private double salaryPerDay;

		public Salary(int noOfDaysWorked, double salaryPerDay) {
			super();
			this.noOfDaysWorked = noOfDaysWorked;
			this.salaryPerDay = salaryPerDay;
		}

		public int getNoOfDaysWorked() {
			return noOfDaysWorked;
		}

		public void setNoOfDaysWorked(int noOfDaysWorked) {
			this.noOfDaysWorked = noOfDaysWorked;
		}

		public double getSalaryPerDay() {
			return salaryPerDay;
		}

		public void setSalaryPerDay(double salaryPerDay) {
			this.salaryPerDay = salaryPerDay;
		}

		@Override
		public String toString() {
			return "Salary [noOfDaysWorked=" + noOfDaysWorked + ", salaryPerDay=" + salaryPerDay + "]";
		}
}


