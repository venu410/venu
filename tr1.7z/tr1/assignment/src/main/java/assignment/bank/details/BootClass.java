package assignment.bank.details;

import java.util.Scanner;

public class BootClass {
	

		public static void main(String[] args) {
			int slotNo = 0;
			int choice;
			String accType;
			double amt;
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);

			Account arr[] = new Account[100];
			UserInteraction ui = new UserInteraction();
			TransactionDAO tr = new TransactionDAOImp();
			try {
				for (;;) {
					
					System.out.println("Enter :\n1.To save Account\n2.To Withdraw\n3.To Deposit\n4.Mini Statement\n5.Exit");
					choice = sc.nextInt();
					switch (choice) {
					case 1:
						Account acc = new Account();
						acc.accountDetails();
						tr.saveAccount(acc, arr);
						break;
					case 2:
						System.out.println("Please enter the account slot number to perform the withdrawl");
						slotNo = sc.nextInt();
						if (arr[slotNo] == null)
							System.out.println("Account do not exsisit");
						else {
							System.out.println("Enter the account type");
							accType = sc.next();
							System.out.println("Enter the withdrawl amount");
							amt = sc.nextDouble();
							tr.withdrawl(arr[slotNo], accType, amt);
						}
						break;
					case 3:
						System.out.println("Please enter the account slot number to perform the deposit");
						slotNo = sc.nextInt();
						if (arr[slotNo] == null)
							System.out.println("Account do not exsisit");
						else {
							System.out.println("Enter the account type");
							accType = sc.next();
							System.out.println("Enter the deposit amount");
							amt = sc.nextDouble();
							tr.deposit(arr[slotNo], accType, amt);
						}
						break;
					case 4:
						if (arr[slotNo] == null)
							System.out.println("Account do not exsisit");
						else {
							System.out.println("Enter the slot number to view the mini statement.");
							slotNo = sc.nextInt();
							ui.viewDetails(arr[slotNo]);
						}
						break;
					case 5:
						System.exit(0);
						break;
					default:
						System.out.println("Please enter numebr between 1-5.");
						break;
					}
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				System.out.println("No more slots to create account in the Bank!");
			}
		}
}


