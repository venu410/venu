package assignment.bank.account.details;

import java.io.Serializable;
	import java.util.Date;

	@SuppressWarnings("serial")
	public class Account implements Serializable {

		private int accountNo;
		private String accountName;
		private Date accountOpenDate;
		// private accountType acType;
		private double amount;
		private Address add;
		private String accountType;

		public Account() {

		}

		public int getAccountNo() {
			return accountNo;
		}

		public void setAccountNo(int accountNo) {
			this.accountNo = accountNo;
		}

		public String getAccountName() {
			return accountName;
		}

		public void setAccountName(String accountName) {
			this.accountName = accountName;
		}

		public Date getAccountOpenDate() {
			return accountOpenDate;
		}

		public void setAccountOpenDate(Date accountOpenDate) {
			this.accountOpenDate = accountOpenDate;
		}

		public double getAmount() {
			return amount;
		}

		public void setAmount(double amount) {
			this.amount = amount;
		}

		public Address getAdd() {
			return add;
		}

		public void setAdd(Address add) {
			this.add = add;
		}

		public String getAccountType() {
			return accountType;
		}

		public void setAccountType(String accountType) {
			this.accountType = accountType;
		}

		@Override
		public String toString() {
			return "Account [accountNo=" + accountNo + ", accountName=" + accountName + ", accountOpenDate="
					+ accountOpenDate + ", amount=" + amount + ", add=" + add + ", accountType=" + accountType + "]";
		}
}


