package assignment.bank.account.details;

	import java.io.File;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.io.ObjectOutputStream;

	public class SerilazationDemo {
		ObjectOutputStream objectOutputStream=null;
		void seriLogic(Account account, File file) throws IOException
		{	
			objectOutputStream = new ObjectOutputStream(new FileOutputStream(file,true));
			objectOutputStream.writeObject(account);
			objectOutputStream.flush();
			objectOutputStream.close();
		}
}


