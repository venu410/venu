package assignment.bank.account.details;


	import java.io.File;
	import java.io.IOException;
	import java.io.ObjectOutputStream;
	import java.util.Date;
	import java.util.Scanner;

	public class UserInteraction {

		@SuppressWarnings("resource")
		void logic(ObjectOutputStream objectOutputStream, File file) throws IOException, ClassNotFoundException {
			Scanner sc = new Scanner(System.in);
			Account account = null;
			Address address = null;
			int choice;
			SerilazationDemo seri;
			DeSerilazationDemo deSeri;
			int tempAccNo;
			

			for (;;) {

				System.out.println(
						"Enter the choice:\n1.To create\n2.To Update\n3.view a particular account\n4.Delete a particular account\n5.View all account details\n6.Exit");
				choice = sc.nextInt();

				switch (choice) {
				case 1:

					account = new Account();
					System.out.println("Enter account number");
					account.setAccountNo(sc.nextInt());
					System.out.println("Enter account user name");
					account.setAccountName(sc.next());
					// System.out.println("Enter account open date");
					account.setAccountOpenDate(new Date());
					System.out.println("Enter account type");
					account.setAccountType(sc.next());
					System.out.println("Enter amount");
					account.setAmount(sc.nextDouble());

					address = new Address();
					System.out.println("Enter Doorn number");
					address.setDoorNo(sc.nextInt());
					System.out.println("Enter street name");
					address.setStreetName(sc.next());
					System.out.println("Enter city name");
					address.setCity(sc.next());
					System.out.println("Enter state name");
					address.setState(sc.next());
					seri = new SerilazationDemo();
					seri.seriLogic(account, file);
					
					break;

				case 2:
					deSeri = new DeSerilazationDemo();
					account = deSeri.deSeriLogic(file);
					System.out.println("Enter the account number to update");
					tempAccNo = sc.nextInt();
					if (account.getAccountNo() == tempAccNo) {
						System.out.println("Enter the amount to updated.");
						double amt = sc.nextDouble();
						account.setAmount(amt);
						seri = new SerilazationDemo();
						seri.seriLogic(account, file);
					} else
						System.out.println("No such account account available");
					break;

				case 3:
					deSeri = new DeSerilazationDemo();
					account = deSeri.deSeriLogic(file);
					System.out.println("Enter the account number to view it's details : ");
					tempAccNo = sc.nextInt();
					if (account.getAccountNo() == tempAccNo) {
						System.out.println(account);
					} else
						System.out.println("No such account account available");
					break;

				}
			}
		}
}


