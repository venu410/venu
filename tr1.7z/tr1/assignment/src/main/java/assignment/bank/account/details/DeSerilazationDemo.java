package assignment.bank.account.details;


	import java.io.File;
	import java.io.FileInputStream;
	import java.io.IOException;
	import java.io.ObjectInputStream;

	public class DeSerilazationDemo {
		
		ObjectInputStream objectInputStream =null;
		Account deSeriLogic(File file) throws IOException, ClassNotFoundException
		{
			objectInputStream = new ObjectInputStream(new FileInputStream(file));
			Account ac1 = (Account) objectInputStream.readObject();
			objectInputStream.close();
			return ac1;
		}
}


