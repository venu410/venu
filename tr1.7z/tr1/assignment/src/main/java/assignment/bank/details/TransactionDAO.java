package assignment.bank.details;

public interface TransactionDAO {
	
		void saveAccount(Account acc, Account arr[]);

		void withdrawl(Account arr,String accountType, double amt);

		void deposit(Account arr, String accountType, double amt);
}



