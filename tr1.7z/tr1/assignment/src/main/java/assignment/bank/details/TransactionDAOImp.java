package assignment.bank.details;

	public class TransactionDAOImp implements TransactionDAO {
		static int count = 0;

		public void saveAccount(Account acc, Account arr[]) {
			arr[count] = acc;
			count++;
			System.out.println("Your account is created!");
		}

		public void withdrawl(Account arr, String accountType, double amt) {

			if (arr.accountType.equalsIgnoreCase("savings")) {
				if (arr.amount >= amt) {
					arr.amount -= amt;
					System.out.println(amt + " withdrawl for savings account was successful");
				} else
					System.out.println("Insufficient balance");
			} else {
				arr.amount += amt;
				System.out.println(amt + " withdrawl for loan account was successful");
			}

		}

		public void deposit(Account arr, String accountType, double amt) {

			if (arr.accountType.equalsIgnoreCase("savings")) {

				{
					arr.amount += amt;
					System.out.println(amt + " deposit for savings account was successful");
				}

			} else {
				arr.amount -= amt;
				System.out.println(amt + " deposit for loan account was successful");
			}
		}
}


