package assignment.bank.account.details;

	import java.io.Serializable;

	@SuppressWarnings("serial")
	public class Address implements Serializable {

		private int doorNo;
		private String streetName;
		private String city;
		private String state;

		public Address() {

		}

		public int getDoorNo() {
			return doorNo;
		}

		public void setDoorNo(int doorNo) {
			this.doorNo = doorNo;
		}

		public String getStreetName() {
			return streetName;
		}

		public void setStreetName(String streetName) {
			this.streetName = streetName;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		@Override
		public String toString() {
			return "Address [dorrNo=" + doorNo + ", streetName=" + streetName + ", city=" + city + ", state=" + state + "]";
		}

}


