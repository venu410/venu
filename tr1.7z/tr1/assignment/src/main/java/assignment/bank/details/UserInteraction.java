package assignment.bank.details;

public class UserInteraction {
	
		void viewDetails(Account acc)
		{
			acc.printAccountDetails(acc);
		}

}



