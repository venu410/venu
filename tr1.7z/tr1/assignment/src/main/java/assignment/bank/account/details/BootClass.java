package assignment.bank.account.details;


	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.io.ObjectOutputStream;
	import java.util.Scanner;

	@SuppressWarnings("unused")
	public class BootClass {

		@SuppressWarnings({ "resource" })
		public static void main(String[] args) {

			Scanner sc = new Scanner(System.in);
			File file = new File("BankDetails.txt");
			FileOutputStream fileOutputtStream = null;
			ObjectOutputStream objectOutputStream = null;

			try {
				file.createNewFile();
			} catch (FileNotFoundException e1) {

				e1.printStackTrace();
			} catch (IOException e1) {

				e1.printStackTrace();
			}

			UserInteraction userInterface = new UserInteraction();
			try {
				userInterface.logic(objectOutputStream, file);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
}


