package assignment.bank.details;

import java.util.Date;
import java.util.Scanner;

public class Account {
	
		int accountNo;
		String accountName;
		Date d;
		String accountType;
		double amount;

		void accountDetails() {
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter account number");
			this.accountNo = sc.nextInt();
			System.out.println("Enter account user name");
			this.accountName = sc.next();
			System.out.println("Enter account type");
			this.accountType = sc.next();
			System.out.println("Enter initial amount");
			this.amount = sc.nextDouble();
			d = new Date();
		}

		void printAccountDetails(Account acc) {
			System.out.println("Account number : " 
							+ acc.accountNo 
							+ "\tAccount user : " 
							+ acc.accountName 
							+ "\tAccount type : "
							+ acc.accountType 
							+ "\tAmount : " 
							+ acc.amount 
							+ "\t Date of account opeing : " 
							+ acc.d);
		}
}


