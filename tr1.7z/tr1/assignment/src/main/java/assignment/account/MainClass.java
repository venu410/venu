package assignment.account;

public class MainClass {

	public static void main(String[] args) {
		Business.getAccountDetails();
		Sort s=new Sort();
		s.sortDetails();

	}

}
