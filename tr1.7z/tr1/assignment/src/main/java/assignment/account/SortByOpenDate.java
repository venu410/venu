package assignment.account;

import java.util.Comparator;

public class SortByOpenDate implements Comparator<Account>{

	@Override
	public int compare(Account acc1, Account acc2) {
		if(acc1.getOpenDate().after(acc2.getOpenDate()))
		return 1;
		else if(acc1.getOpenDate().before(acc2.getOpenDate()))
			return -1;
		return 0;
	}
	
	

}
