package assignment.account;

import java.util.Comparator;

public class SortByName implements Comparator<Account>{
	

		public int compare(Account acc1, Account acc2) {
			if(acc1.getAccountName().compareTo(acc2.getAccountName())>0)
				return 1;
			else if(acc1.getAccountName().compareTo(acc2.getAccountName())<0)
				return -1;
			else 
				return 0;
		}

}
