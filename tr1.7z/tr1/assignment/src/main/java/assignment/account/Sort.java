package assignment.account;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

public class Sort {
	public void sortDetails() {
		@SuppressWarnings("resource")
		Scanner scan=new Scanner(System.in);
		int choice;
		ArrayList<Account> list=Business.getAccountDetails();
		do
		{
			System.out.println("1. sort by account number");
			System.out.println("2. sort by account name");
			System.out.println("3. sort by Account Type");
			System.out.println("4. sort by city");
			System.out.println("5. sort by open date");
			System.out.println("6.exit");
			System.out.println("enter your choice");
			choice=scan.nextInt();
			switch(choice){
			case 1:
			Collections.sort(list,new SortByAccountNum());
			Iterator<Account> itr=list.iterator();
			while(itr.hasNext())
				System.out.println(itr.next());
			break;
			case 2:
				Collections.sort(list,new SortByName());
				 itr=list.iterator();
				while(itr.hasNext())
					System.out.println(itr.next());
				break;
			case 3:
				Collections.sort(list,new SortByAccountType());
				itr=list.iterator();
				while(itr.hasNext())
					System.out.println(itr.next());
				break;
			case 4:
				Collections.sort(list,new SortByCity());
				itr=list.iterator();
				while(itr.hasNext())
					System.out.println(itr.next());
				break;
			case 5:
				Collections.sort(list,new SortByOpenDate());
				itr=list.iterator();
				while(itr.hasNext())
					System.out.println(itr.next());
				break;
			case 6:
				System.exit(0);
			
			}
			
		
		}while(choice!=0);
	}
}

	
	


