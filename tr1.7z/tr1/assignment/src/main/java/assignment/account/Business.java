package assignment.account;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;



public class Business {
	public static ArrayList<Account> getAccountDetails()
	{
		Address add1=new Address(121,"s.p.colony","chennai","tamilanadu");
		Address add2=new Address(231,"A.R.Nagar","karnataka","banglore");
		Address add3=new Address(764,"BigColony","ranchi","Jarkhand");
		Address add4=new Address(645,"Lecturers colony","hyderabad","telangana");
		Address add5=new Address(904,"Ramoji nagar","vijayawada","A.P");
	
	
		SimpleDateFormat adf=new SimpleDateFormat("dd/mm/yyyy");
		String str1="23/07/1993";
		String str2="16/12/1998";
		String str3="04/08/2001";
		String str4="31/11/2006";
		String str5="08/02/2012";
		Date date1=null,date2=null,date3=null,date4=null,date5=null;
		try {
			date1=adf.parse(str1);
			date2=adf.parse(str2);
			date3=adf.parse(str3);
			date4=adf.parse(str4);
			date5=adf.parse(str5);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Account acc1=new Account(12548756,"venukumar","savings",date1,25000,add1);
		Account acc2=new Account(58963245,"Rakesh Sharma","current",date2,25639,add2);
		Account acc3=new Account(69325894,"renuka beti","savings",date3,56932,add3);
		Account acc4=new Account(25369458,"ramesh babu","current",date4,62539,add4);
		Account acc5=new Account(42586702,"keerthana reddy","savings",date5,48569,add5);
	
		ArrayList<Account> al=new ArrayList<>();
		al.add(acc1);
		al.add(acc2);
		al.add(acc3);
		al.add(acc4);
		al.add(acc5);
		Iterator<Account> itr=al.iterator();
		while(itr.hasNext())
		{
			
			@SuppressWarnings("unused")
			Account acc=itr.next();
			//System.out.println(acc);
		}
		return al;
	}

}
