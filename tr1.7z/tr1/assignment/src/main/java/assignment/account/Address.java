package assignment.account;

public class Address {
	private int doorNum;
	private String street,city,state;
	public Address() {
		
	}
	public Address(int doorNum, String street, String city, String state) {
		super();
		this.doorNum = doorNum;
		this.street = street;
		this.city = city;
		this.state = state;
	}
	public int getDoorNum() {
		return doorNum;
	}
	public void setDoorNum(int doorNum) {
		this.doorNum = doorNum;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "Address [doorNum=" + doorNum + ", street=" + street + ", city=" + city + ", state=" + state + "]";
	}
	
	

}
