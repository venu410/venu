package assignment.account;

import java.util.Comparator;

public class SortByAccountNum implements Comparator<Account> {

	@Override
	public int compare(Account acc1, Account acc2) {
		if(acc1.getAccountNumber()>acc2.getAccountNumber()) 
			return 1;
		else if(acc1.getAccountNumber()<acc2.getAccountNumber())
			return -1;
		else
			return 0;
		
	}
	

}
