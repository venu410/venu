package assignment.thread.demo;

public class Accountmain {

	public static void main(String[] args) {
		final Account account=new Account();
		
		Thread t1=new Thread(){
			@Override
			public void run(){
				account.consumeProduct(400);
			}
		};
		
		Thread t2=new Thread(){
			@Override
			public void run(){
				account.produceProduct(1000);
			}
		};
		
		Thread t3=new Thread(){
			@Override
			public void run(){
				account.consumeProduct(800);
			}
		};
		
		Thread t4=new Thread(){
			@Override
			public void run(){
				account.consumeProduct(1000);
			}
		};
		
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();

	}



}


