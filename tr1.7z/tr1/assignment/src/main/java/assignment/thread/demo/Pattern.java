package assignment.thread.demo;

public class Pattern extends Thread{
	@SuppressWarnings("unused")
	private static String name;
	

	/*public Pattern(String name) {
		this.name=name;*/
		
	//}
	synchronized  public void printPattern( String name)
	{
		for(int i=0;i<=name.length();i++)
		{
			System.out.println(name.substring(0,i));
		}
		
			
	}
	public void run(String name)
	{
		printPattern(name);
		//System.out.println("venu");
	}
	
	
}
	
	

