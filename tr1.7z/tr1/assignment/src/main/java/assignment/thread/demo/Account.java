package assignment.thread.demo;

public class Account {
	private double balance=500;
	public void consumeProduct(double bal)
	{
		while(this.balance<500){
			System.out.println("Insufficient balance!");
			
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		this.balance-=bal;
		System.out.println("balance debited. Updated Quantity=" + this.balance);
		
		
	}
	
	
	synchronized public void produceProduct(int bal){
		System.out.println("deposit started");
		this.balance+=bal;
		System.out.println("balance deposited" + this.balance);
		
		notify();
		
	}
		
}


