package assignment.thread.demo;



public class Multiplication extends Thread {
	private int num;
	public Multiplication(int num)
	{
		this.num=num;
	}

	public void run()
	{
		
		
		for(int i=1;i<=10;i++)
			
			System.out.println(num +"*"+i+"="+(i*num));
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
	}

}
