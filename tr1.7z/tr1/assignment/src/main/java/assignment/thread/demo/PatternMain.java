package assignment.thread.demo;

public class PatternMain {

	public static void main(String[] args) {
		
		/*Pattern pattern1=new Pattern("capgemini");
		Pattern pattern2=new Pattern("venukumar");
		Pattern pattern3=new Pattern("happy birthday");
		pattern1.start();
		pattern2.start();
		pattern3.start();*/
		final Pattern pattern2=new Pattern();
		Thread thread1=new Thread(){
			public void run()
			{
				pattern2.printPattern("capgemini");
				
			}
		};
		thread1.start();
		Thread thread2=new Thread(){
			public void run()
			{
				pattern2.printPattern("venukumar");
				
			}
		};
		thread2.start();
		Thread thread3=new Thread(){
			public void run()
			{
				pattern2.printPattern("HappyBirthday");
				
			}
		};
		thread3.start();

	}

}
