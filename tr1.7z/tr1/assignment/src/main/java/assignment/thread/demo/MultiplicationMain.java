package assignment.thread.demo;

public class MultiplicationMain {

	public static void main(String[] args) {
		Multiplication mul1=new Multiplication(5);
		
		Multiplication mul2=new Multiplication(10);
		Multiplication mul3=new Multiplication(15);
		mul1.start();
		mul2.start();
		mul3.start();
	}

}
