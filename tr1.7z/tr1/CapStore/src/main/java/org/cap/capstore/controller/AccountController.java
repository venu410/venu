package org.cap.capstore.controller;

import javax.validation.Valid;

import org.cap.capstore.dto.AccountDetails;
import org.cap.capstore.service.AccountService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class AccountController {
	
	
	//creating reference for service
	@Autowired
	private AccountService accService;
	
	//mapping the list jsp file
	@RequestMapping("/accForm")
	public String show(ModelMap map){
		map.put("acc", new AccountDetails());
		return "list";
	}
	
	//mapping the credit form
	@RequestMapping("/showcredit")
	public ModelAndView showCreditDetails(){
		return new ModelAndView("credit", "acc", new AccountDetails());
	}
	
	//mapping the debit form
	@RequestMapping("/showdebit")
	public String showDebitDetails(){
		return "debit";
	}
	
	
	//mapping the netbanking form
	@RequestMapping("/shownetbanking")
	public String shownetBankingDetails(){
		return "netbanking";
	}
	
	//mapping the cash on delivery form
	@RequestMapping("/showcod")
	public String showCodDetails(){
		return "cod";
	}
	
	
	@RequestMapping(value="/saveAccount",method=RequestMethod.POST)
	public String saveAccount(@Valid @ModelAttribute("acc") AccountDetails account,
			BindingResult result){
		
		if(!result.hasErrors()){
			
			accService.saveAccount(account);
			return "redirect:accForm";
			
			
		}else{
			return "account";
		}
		
		
	}
	
	//show the success page for credit details
	@RequestMapping("/showSuccess")
	public String showcreditsuccesspage() 
	{
		return "success";
	}
	
	
	//show the success page for debit details
	@RequestMapping("/showDebitSuccess")
	public String showDebitSuccessPage()
	{
		return "success";
	}
	
	
	//show the success page for netbanking details
	@RequestMapping("/showNetBanking")
	public String showNetBankingpage()
	{
		return "success";
	}
	
	
	//show the success page for cash on delivery details
	@RequestMapping("/showCod")
	public String showCashOnDelivery()
	{
		return "success";
	}
	
}
