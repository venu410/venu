package org.cap.capstore.dao;

import org.cap.capstore.dto.AccountDetails;

public interface AccountDao {
	
	public void saveAccount(AccountDetails account);
	

}
