package org.cap.capstore.service;

import org.cap.capstore.dao.AccountDao;
import org.cap.capstore.dto.AccountDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AccountServiceImpl implements AccountService {
	
	@Autowired
	private AccountDao accDao;

	@Transactional
	public void saveAccount(AccountDetails account) {
		
		accDao.saveAccount(account);
		
		
	}

}
