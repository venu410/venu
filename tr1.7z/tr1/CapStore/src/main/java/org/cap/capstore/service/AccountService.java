package org.cap.capstore.service;

import org.cap.capstore.dto.AccountDetails;

public interface AccountService {
	
	public void saveAccount(AccountDetails account);

}
