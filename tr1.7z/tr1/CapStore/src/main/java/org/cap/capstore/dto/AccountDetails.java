package org.cap.capstore.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
@Table
public class AccountDetails {

	@Id
	@Range(min=16,max=16,message="*Please enter 16 digit card No.")
	private int cardNumber;
	
	@Temporal(TemporalType.DATE)
	private Date expiryDate;
	
	@Column(nullable=false)
	@NotEmpty(message="*Please enter card name.")
	private String cardOnName;
	
	@Column(nullable=false)
	@NotEmpty(message="*Please enter card cvv.")
	private int cvv;

	public AccountDetails() {}

	public AccountDetails(int cardNumber, Date expiryDate, String cardOnName, int cvv) {
		super();
		this.cardNumber = cardNumber;
		this.expiryDate = expiryDate;
		this.cardOnName = cardOnName;
		this.cvv = cvv;
	}

	public int getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(int cardNumber) {
		this.cardNumber = cardNumber;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getCardOnName() {
		return cardOnName;
	}

	public void setCardOnName(String cardOnName) {
		this.cardOnName = cardOnName;
	}

	public int getCvv() {
		return cvv;
	}

	public void setCvv(int cvv) {
		this.cvv = cvv;
	}

	@Override
	public String toString() {
		return "AccountDetails [cardNumber=" + cardNumber + ", expiryDate=" + expiryDate + ", cardOnName=" + cardOnName
				+ ", cvv=" + cvv + "]";
	}





}
