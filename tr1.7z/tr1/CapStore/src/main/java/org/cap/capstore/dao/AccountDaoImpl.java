package org.cap.capstore.dao;

import org.cap.capstore.dto.AccountDetails;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

//implementing the Dao layer
@Repository
public class AccountDaoImpl implements AccountDao{
	
	//creating reference for sessionfactory
	@Autowired
	private SessionFactory sessionFactory;

	@Transactional
	public void saveAccount(AccountDetails account) {
		sessionFactory.getCurrentSession().save(account);
		
		
	}

}
