package assessment.practise.demo;

public class Main {
	Pair pair=new Pair(10,12);
	

}
