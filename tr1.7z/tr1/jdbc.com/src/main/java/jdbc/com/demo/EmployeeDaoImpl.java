package jdbc.com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EmployeeDaoImpl implements EmployeeDao{

	public int addEmployee(Employee employee) {
		int count=0;
		String sql="insert into employee values(?,?,?,?,?,?)";
		try {
			PreparedStatement pst=getMySQlConnection().prepareStatement(sql);
			pst.setInt(1, employee.getEmpId());
			pst.setString(2, employee.getFirstName());
			pst.setString(3, employee.getLastName());
			pst.setDouble(4, employee.getSalary());
			pst.setInt(5, employee.getDepartmentId().getDepartmentId());
			pst.setString(6, employee.getEmail());
			
			count=pst.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return count;
		
	}
	
	
	
	public  Connection getMySQlConnection(){
		
		Connection conn=null;
		try {
			
			//Load Driver Class
			Class.forName("com.mysql.jdbc.Driver");
			
			//Establish Connection
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}
	

}
