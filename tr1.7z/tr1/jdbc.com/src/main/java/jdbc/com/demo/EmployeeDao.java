package jdbc.com.demo;

public interface EmployeeDao {
	
	public int addEmployee(Employee employee);

}
