package org.cap.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FeedbackServlets
 */
public class FeedbackServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	/*
	@Override
	public void init(ServletConfig config) throws ServletException {
		String email=config.getInitParameter("feedbckEmail");
		System.out.println(email);
	}
*/



	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		ServletContext servletCntx=getServletContext();
		
		String compEmail=servletCntx.getInitParameter("companyEmail");
		ServletConfig config=getServletConfig();
		
		String complEmail=config.getInitParameter("feedbckEmail");
		
		

		
		String cname=request.getParameter("clientName");
		String cmts=request.getParameter("clientCmts");
		
		out.println("<html>"
				+ " <h3>Hi! " + cname +" <br> "
						+ "Your Comment :" + cmts
						+"Send to out Company Email :" + compEmail
				+ "</h3>"
				+ "<br>"
				+ "<br>"
				+ "<hr>"
				+ "<b>"+ servletCntx.getServerInfo()+"</b> <br>"
						+ "<b>"+ servletCntx.getMajorVersion()+"</b> <br>"
								+ "<b>"+ servletCntx.getMinorVersion()+"</b> <br>"
										+ "<b>"+ config.getServletName()+"</b> <br>"
												
								
				+ "<h2>Your Complaints are here: "+ complEmail+"</h2>"
				+ "</html>");
		
	}

}
