package com.flp.pms.DaoJDBC;

public interface IProductJDBCDao {

	
	
	
	
	
}