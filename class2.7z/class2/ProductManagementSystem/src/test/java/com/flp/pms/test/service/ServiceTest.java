package com.flp.pms.test.service;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Map;


import org.junit.BeforeClass;
import org.junit.Test;


import com.flp.pms.domain.Category;
import com.flp.pms.domain.Product;
import com.flp.pms.service.ProductServiceImpl;

import static org.hamcrest.CoreMatchers.*;



public class ServiceTest {

	
	static ProductServiceImpl pService;
	
	@BeforeClass
	public static void setUp(){
		pService=new ProductServiceImpl();
	}
	
	
	@Test
	public void countAllCategories(){
		List<Category> categories=pService.getAllCategory();
		assertEquals(5, categories.size());
	}
	
	
	@Test
	public void countAllCategoriesWithAllOptions(){
		List<Category> categories=pService.getAllCategory();
		assertThat(categories.size(),allOf(is(5) ,instanceOf(Integer.class) ) );
	}
	
	@Test
	public void testGetAllProducts(){
		
		Map<Integer, Product> map=pService.getAllProducts();
		assertEquals(true, map.isEmpty());
	}
	
}
