function changeStyle(){
	var objBold=myForm.chkBold.checked;
	
	var mytxt=document.getElementById('cntDiv').textContent;
	
	if(obj)
		document.getElementById('cntDiv').innerHTML="<b>"+mytxt+"</b>";
	else
		document.getElementById('cntDiv').innerHTML=mytxt;
}

/*function changeItalics(){
	var obj=myForm.chkItalics.checked;
	var mytxt=document.getElementById('cntDiv').textContent;
	
	if(obj)
		document.getElementById('cntDiv').innerHTML="<i>"+mytxt+"</i>";
	else
		document.getElementById('cntDiv').innerHTML=mytxt;
}*/