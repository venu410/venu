package org.capgemini.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SelectEmployee {

	public static void main(String[] args) {
		Connection conn=null;
		try {
			
			//Load Driver Class
			Class.forName("com.mysql.jdbc.Driver");
			
			//Establish Connection
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","admin");
			
			
			String sql="alter table employee add email varchar(50) not null";
			
			PreparedStatement pst=conn.prepareStatement(sql);
			boolean flag=pst.execute();
			
			if(!flag)
				System.out.println("Table Altered");
			else
				
				System.out.println("Table alteration error!");
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			/*String sql="select * from employee where salary>?";
			PreparedStatement pst=conn.prepareStatement(sql);
			
			pst.setDouble(1, 20000);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				System.out.println(rs.getInt(1) + "-->"+
				rs.getString("firstname")+ "-->"+
				rs.getString("lastname")+ "-->"+
				rs.getDouble(4)+ "-->"+
				rs.getInt(5));
			}
			
			pst.close();*/
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
