/*var objBold;
var objItalics;
var mytxt=document.getElementById('cntDiv').textContent;

function changeStyle(){
	var objBold=myForm.chkBold.checked;
	
	if(objBold)
		document.getElementById('cntDiv').innerHTML="<b>"+mytxt+"</b>";
	else
		document.getElementById('cntDiv').innerHTML=mytxt;
}

function changeItalics(){
	var objItalics=myForm.chkItalics.checked;
	alert(objBold);
	alert(objItalics);
	if(objBold){
		if(objItalics)
			document.getElementById('cntDiv').innerHTML="<i><b>"+mytxt+"</b></i>";
		else
			document.getElementById('cntDiv').innerHTML="<b>"+mytxt+"</b>";
	}else
		document.getElementById('cntDiv').innerHTML=mytxt;
	}*/


function changeStyle(){
	var txtStyles=myForm.chkStyles;
	var mytxt=document.getElementById('cntDiv').textContent;

			if(txtStyles[0].checked &&
					txtStyles[1].checked &&
						txtStyles[2].checked)
				document.getElementById('cntDiv').innerHTML="<i><b><u>"+mytxt+"</u></b></i>";
			else if(txtStyles[0].checked &&
					txtStyles[1].checked)
				document.getElementById('cntDiv').innerHTML="<i><b>"+mytxt+"</b></i>";
			else if(txtStyles[0].checked)
				document.getElementById('cntDiv').innerHTML="<b>"+mytxt+"</b>";
			else
				document.getElementById('cntDiv').innerHTML=mytxt;
	
}

function changeColor(){
	//var mytxt=document.getElementById('cntDiv').innerHTML;
	
	//alert(mytxt);
	var selColor=myForm.txtColor.value;
	
	document.getElementById('cntDiv').style.color=selColor;
	
}

function changeFontFace(){
	var selFont=myForm.myFont.value;
	document.getElementById('cntDiv').style.fontFamily=selFont;
}

function showArray(){
	var totalNums=parseInt(prompt('Enter how many elements?'));
	var myArr=new Array(totalNums);
	
	
	for(var i=0;i<totalNums;i++)
		{
		myArr[i]=prompt('Enter element:');
		document.write(myArr[i]+"<br>");
		}
	
	document.write("<hr>");
	
	var sumArr=sumArray(myArr);
	document.write("Sum Of Array:" + sumArr +"<br>");
	
}

function sumArray(myArray){
	var sum=0;
	for(var i=0;i<myArray.length;i++)
		sum=sum+parseInt(myArray[i]);
	return sum;
}

function createTextBoxes(){
	var nums=parseInt(f1.totNums.value);
	
	for(var i=0;i<nums;i++){
		document.getElementById('txtBox').innerHTML=
			document.getElementById('txtBox').innerHTML+"<input type='text' name='t1'> <br><br>";
		
	}
	
}


function showTwoDimArray(){
	/*var myArr=new Array(2);
	myArr[0]=new Array(3);
	myArr[1]=new Array(3);
	for(var i=0;i<2;i++){
		for(var j=0;j<3;j++){
			myArr[i][j]=prompt('Enter Value:');
			document.write(myArr[i][j]);
		}
	}*/
	
	var weeks=new Array('sun','mon','tue','wed');
	
	for(var i=0;i<weeks.length;i++)
		document.write(weeks[i]+"<br>");
	
}















function displayDiv(){
	document.getElementById('divSingle').style.visibility='hidden';
	document.getElementById('divMarried').style.visibility='hidden';
}

function showDiv(){
	var status=myForm.mstatus.value;
	//alert(status);
	if(status=='Single'){
		window.location.href='demo1.html';
		document.getElementById('divSingle').style.visibility='visible';
		document.getElementById('divMarried').style.visibility='hidden';

	}else if(status=='Married'){
		window.location.href='https://www.google.co.in/#gfe_rd=cr&gws_rd=ssl';
		document.getElementById('divSingle').style.visibility='hidden';
		document.getElementById('divMarried').style.visibility='visible';

	}
		
}
var win;
function openWindow(){
	win=window.open('https://www.google.co.in/#gfe_rd=cr&gws_rd=ssl');
}

function closeWindow(){
	//win.close();
	window.close();
}


function goback(){
	window.history.back();
}
function goForward(){
	window.history.forward();
}

function show(){
	
	var addNum=(function(){
		var num1,num2;
		
		num1=parseInt(prompt('Enter your First Number:'));
		num2=parseInt(prompt('Enter Second Number'));
		
		return num1+num2;
		
	});
	
	var num=addNum();
	alert(num);
	
}


var myTime=(function showTime(){
	Date d=new Date();
	alert(d);
	document.getElementById('divTime').innerHTML=d.toLocaleTimeString();
});
	
	function demo1(){
		alert('hai');
		//myTime();
	}



















