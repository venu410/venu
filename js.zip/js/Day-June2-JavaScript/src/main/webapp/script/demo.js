var myTime;
function showData(){
	
	myTime=(function showTime(){
	var d=new Date();
	document.getElementById('divTime').innerHTML=d.toLocaleTimeString();
});
	setInterval(myTime,500);
	
}


function stop(){
	alert('Hai');
	clearInterval(myTime);
	//clearTimeout(myTime);
}
/*
function show(){
	setInterval((function(){
		var d=new Date();
		document.getElementById('divTime').innerHTML=d.toLocaleTimeString();
	}), 500);

}
*/
