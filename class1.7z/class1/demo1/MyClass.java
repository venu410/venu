package org.capgemini.demo;

public class MyClass {

	public static void main(String[] args) {
		System.out.println("Hello World!");

	}

}
