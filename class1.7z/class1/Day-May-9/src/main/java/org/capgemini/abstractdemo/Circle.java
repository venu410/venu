package org.capgemini.abstractdemo;

public class Circle extends Shape{

	@Override
	public void draw() {
		System.out.println("Draw - Circle");
		
	}

	
}
