package org.capgemini.demo;

public interface RectangleOnCorcle extends Shape,Color,Graphics {

	public void drawRect_Circle();
}
