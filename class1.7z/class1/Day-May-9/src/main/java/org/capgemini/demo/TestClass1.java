package org.capgemini.demo;

public class TestClass1 {

	public static void main(String[] args) {
		Employee employee1=new Employee(1, "tom", "jerry");
		Employee employee2=new Employee(1, "tom", "jerry");
		employee1=employee2;
		System.out.println(employee1.equals(employee2));
		System.out.println(employee1==employee2);
	}

}
