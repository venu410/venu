package org.capgemini.demo;

public class Rectangle implements Shape,Color{

	public void draw() {
		System.out.println("Draw Rectangle");
		
	}

	public void getPoints() {
		System.out.println("Get Rectangle points");
	}

	
	public void Rectinfo(){
		System.out.println("Rectangle - Info");
	}

	public void getColor() {
		System.out.println("Rectangle - getColor");
		
	}

	public void fillColor() {
		System.out.println("Fill Rectangle ");
		
	}
}
