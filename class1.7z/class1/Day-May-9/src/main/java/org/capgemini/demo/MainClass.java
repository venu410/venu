package org.capgemini.demo;

public class MainClass {

	public static void main(String[] args) {
		/*StringBuffer str=new StringBuffer("Tom");
		
		str.append("Welcome to capgemini India Pvt Ltd!.,");
		
		System.out.println("Length:" + str.length());
		System.out.println("Capacity:" + str.capacity());*/
		
		System.out.println("Min Value:" + Integer.MIN_VALUE);

		System.out.println("Max Value:" + Integer.MAX_VALUE);
		
		System.out.println("Size:" + Integer.SIZE);
		
		System.out.println("Bytes:" + Integer.BYTES);
	}

}
