package org.cap.demo.emp;

public enum WeekDays {
	SUN,MON,TUE,WED,THR,FRI,SAT;

}
