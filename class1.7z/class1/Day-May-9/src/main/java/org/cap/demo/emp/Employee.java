package org.cap.demo.emp;

import java.util.Scanner;

public class Employee {
	
	private int empId;
	private String firstName;
	private String lastName;
	private double salary;
	private WeekDays holiday;
	
	
	public void getDetails(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Id:");
		empId=sc.nextInt();
		System.out.println("Enter Employee FirstName:");
		firstName=sc.next();
		
		System.out.println("Enter Employee LastName:");
		lastName=sc.next();
		
		System.out.println("Enter Employee Salary:");
		salary=sc.nextDouble();
		
			System.out.println("Choose Your Holiday:");
			System.out.println("1.Sunday");
			System.out.println("2.Monday");
			System.out.println("3.Tuesday");
			System.out.println("4.Wednesday");
			System.out.println("5.Thursday");
			System.out.println("6.Friday");
			System.out.println("7.Saturday");
			
			int choice=sc.nextInt();
			
			switch(choice){
			case 1:
				holiday=WeekDays.SUN;
				break;
			case 2:
				holiday=WeekDays.MON;
				break;
			case 3:
				holiday=WeekDays.TUE;
				break;
			case 4:
				holiday=WeekDays.WED;
				break;
			case 5:
				holiday=WeekDays.THR;
				break;
			case 6:
				holiday=WeekDays.FRI;
				break;
			case 7:
				holiday=WeekDays.SAT;
				break;
			}
				

		
	}
	
	public void printDetails(){
		System.out.println("\nId :"+ empId 
				+"\nFirstName:" + firstName
				+"\nLastName:" + lastName
				+"\nSalary:" +salary
				+"\nHoliday:" + holiday);
	}
	
	public static void main(String[] args){
		Employee employee=new Employee();
		employee.getDetails();
		employee.printDetails();
	}

}
