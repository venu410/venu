package org.cap.demo;

import java.util.Collection;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DemoMap {

	public static void main(String[] args) {
		/*Map map=new HashMap();
		map.put(1, "Tom");
		map.put("two", new Date());
		map.put(23.45, 20000000L);
		*/
		
		//Map<Integer, String> map=new HashMap<Integer, String>();
		//HashMap<Integer, String> map=new HashMap<Integer, String>();
		//LinkedHashMap<Integer, String> map=new LinkedHashMap<Integer, String>();
		Hashtable<Integer, String> map=new Hashtable<Integer, String>();
		
		map.put(1, "Tom");
		map.put(11, "Tom");
		map.put(1, "jas");
		//map.put(13,null);
		map.put(167, "Kamal");
		map.put(3, "Singh");
		/*map.put(null, "null");
		map.put(null, null);*/
		
		System.out.println(map);
	
		
		
		Enumeration<String> enums=map.elements();
		//System.out.println(enums);
		while(enums.hasMoreElements()){
			String val=enums.nextElement();
			System.out.println(val);
		}
		
		
	
		/*Set<Entry<Integer, String>> entries=map.entrySet();
		System.out.println(entries);
		
		Iterator<Entry<Integer, String>> it=entries.iterator();
		while(it.hasNext())
		{
			Entry<Integer, String> entry=it.next();
			if(entry.getKey()==13)
				it.remove();
			System.out.println(entry.getKey() + "--" + entry.getValue());
			System.out.println(map);
		}
		System.out.println("______________");
		
		System.out.println(entries);
		System.out.println(map);*/
		
		
		
		/*Set<Integer> keys=map.keySet();
		
		
	System.out.println(keys);
		Iterator<Integer> it=keys.iterator();
		while(it.hasNext()){
			Integer key=it.next();
			if(key==13)
				it.remove();
			System.out.println(key+"--"+map.get(key));
			System.out.println(map);
		}
		
		System.out.println("______________");
		System.out.println(keys);
		System.out.println(map);
		*/
		/*Collection<String> vals=map.values();
		System.out.println(vals);*/
	}

	

}
 