package org.cap.test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.cap.trackingservice.TrackingService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;


@RunWith(Parameterized.class)
public class TestManyParameters {

	private static TrackingService service=new TrackingService();
	
	private int input;
	private int output;
	
	
	public TestManyParameters(int input, int output) {
		this.input = input;
		this.output = output;
	}
	
	@Parameters
	public static List<Object[]> data(){
		return Arrays.asList(new Object[][]{
			{5,5},
			{10,15},
			{-5,0}
		});
	}
	
	@Test
	public void testTrackingService(){
		System.out.println(this.input);
		if(this.input>0){
			
			service.produceProduct(this.input);
		}
		else
			service.consumeProduct(this.input);
		
		assertEquals(this.output, service.getTotal());
	}

}
