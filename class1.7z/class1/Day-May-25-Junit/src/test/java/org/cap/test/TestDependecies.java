package org.cap.test;

import static org.junit.Assert.*;

import org.cap.trackingservice.InvalidGoalException;
import org.cap.trackingservice.Notifier;
import org.cap.trackingservice.Product;
import org.cap.trackingservice.TrackingService;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Test;

public class TestDependecies {
	
	TrackingService service=new TrackingService();

	@Test
	public void whenGoalMetTriggerNotifier() throws InvalidGoalException {
		
		Mockery context=new Mockery();
		final Notifier mockNotifier = context.mock(Notifier.class);
		service = new TrackingService(mockNotifier);
		
		context.checking(new Expectations() {{
			oneOf(mockNotifier).send("Goal Met!");
			will(returnValue(false));
		}});
		
		service.setGoal(5);
		service.produceProduct(6);
		
		Product result = service.getProducts().get(1);
		assertEquals("Goal Success:Goal Met!", result.getOpeartion());
		
		context.assertIsSatisfied();

		
	}

}
