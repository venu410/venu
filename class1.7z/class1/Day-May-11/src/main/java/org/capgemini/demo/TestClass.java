package org.capgemini.demo;

public class TestClass {

	public static void main(String[] args) {
		int age=12;
		
		try{
		if(age<18)
			throw new InvalidAgeException("Yeah! I am minor!");
			//throw new InvalidAgeException();
		else
			System.out.println("Eligible for Vote");
		}catch(InvalidAgeException e){
			System.out.println(e.getMessage());
		}
		
		
		System.out.println("Execution continues!");
		}

}
