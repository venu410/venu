package org.cap.demo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class Demo {

	public static void main(String[] args) {
		//Iterable it=new ArrayList();
		//Collection lst=new ArrayList();
		//List myList=new ArrayList();
		
		
		
		ArrayList<Integer> myList=new ArrayList<Integer>();
		
		//myList
		
		
		myList.add(23);
		/*myList.add("Tom");
		myList.add(false);
		myList.add("Tom");*/
		//myList.add(null);
		myList.add(23);
		myList.add(343);
		myList.add(null);
		/*myList.add(12.56);
		myList.add(1000000000L);
		myList.add("Tom");
		myList.add("Tom");
		myList.add(new Object());*/
		//myList.add(null);
		//myList.add(null);
		myList.add(11);
		myList.add(3);
		
		
		
		
		/*
		Iterator<Integer> it=myList.iterator();
		//myList.add(67);
		
		while(it.hasNext()){
			Integer num=it.next();
			if(num==null)
				it.remove();
			System.out.print(num + "-->");
		
		}
		*/
		System.out.println(myList);
		
		ListIterator<Integer> itLst= myList.listIterator();
		itLst.next();
		itLst.next();
		itLst.next();
		itLst.next();
		while(itLst.hasNext()){
			Integer num=itLst.next();
			System.out.print(num + "-->");
			itLst.add(1);
			itLst.add(2);
			itLst.add(3);
		}
		System.out.println("\n");
		
		/*while(itLst.hasPrevious()){
			Integer num=itLst.previous();
			//if(num==null)
				//itLst.remove();
			
			//itLst.set(100);
			System.out.print(num + "-->");
		}*/
		System.out.println("\n");
		
		System.out.println(myList);
		
		
		//System.out.println(myList.get(4));

	}

}
