package org.cap.demo;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class DemoVector {

	public static void main(String[] args) {
	
		Vector<String> mylst=new Vector<>(15,5);
		mylst.add("tom");
		mylst.add("jerry");
		
		mylst.add("tom");
		mylst.add("tom");
		mylst.add("tom");
		mylst.add("tom");
		mylst.add("tom");
		mylst.add("jack");
		
		/*mylst.add("sam");
		mylst.add("tom");
		mylst.add(null);
		mylst.add(null);
		mylst.add("jack");
		mylst.add("jack");
		mylst.add("jack");
		mylst.add("jack");
		*/
		
		System.out.println(mylst);
		System.out.println("Size:" + mylst.size());
		System.out.println("Capacity:" + mylst.capacity());
		
		
		
		
		for(String str:mylst)
			System.out.print(str + "-->");
		
		
		Iterator<String> it=mylst.iterator();
		System.out.println();
		
		while(it.hasNext())
			System.out.print(it.next()+"-->");
		
		
		System.out.println();
		
		
		
		Enumeration<String> mypoint= mylst.elements();
		while(mypoint.hasMoreElements()){
			System.out.print(mypoint.nextElement()+"-->");
			//mypoint.
		}
		
	
		
		
		
		
		
		
		
		
	}

}
