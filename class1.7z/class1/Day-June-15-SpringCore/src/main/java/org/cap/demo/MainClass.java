package org.cap.demo;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class MainClass {

	public static void main(String[] args) {
		
		//ApplicationContext context=new ClassPathXmlApplicationContext("myBean.xml");
		
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("myBean.xml");
		
		//ApplicationContext context=new FileSystemXmlApplicationContext("D:\\Users\\vidavid\\Desktop\\myBean.xml");
		
		//XmlBeanFactory context=new XmlBeanFactory(new ClassPathResource("myBean.xml"));
		
		Employee employee=(Employee)context.getBean("emp");
		//Employee employee1=(Employee)context.getBean("emp");
		
		//employee1.setEmpName("Annie");
		
		System.out.println(employee);
		//System.out.println(employee1);
		
		context.registerShutdownHook();
	}

}
