package org.cap.demo;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class TestClass {

	public static void main(String[] args) {
		
		Date today=new Date();
		
		System.out.println(today);
		System.out.println(today.getDate());
		System.out.println(today.getMonth());
		System.out.println(today.getYear()+1900);
		System.out.println(today.getHours());
		System.out.println(today.getMinutes());
		
		
		
		SimpleDateFormat myFormat=new SimpleDateFormat("dd-M-yyyy , G");
		String myDate=myFormat.format(today);
		System.out.println(myDate);
		
		/*Calendar myDate=new GregorianCalendar();
		System.out.println(myDate);
		
		System.out.println(myDate.get(Calendar.DAY_OF_MONTH));
		System.out.println(myDate.get(Calendar.DAY_OF_WEEK));
		System.out.println(myDate.get(Calendar.YEAR));
		
		System.out.println(myDate.getWeekYear());*/
	}

}
