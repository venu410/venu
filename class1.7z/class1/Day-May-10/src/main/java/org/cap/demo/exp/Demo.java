package org.cap.demo.exp;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;



public class Demo {
	
	public static void main(String[] args){
		
		
		
		String num1="100s";
				int num2=0;
				int num=0;
		try{
			
			
			num=Integer.parseInt(num1);
			
				
		}
		catch (NumberFormatException e) {
			try{
				int ans=120/num2;
				System.out.println("answer : "+ ans);
			}catch(NullPointerException e1){
				System.out.println(e1.getMessage());
			}
			System.out.println("Format Error:" + e.getMessage());
		}
		catch (ArithmeticException e) {
			System.out.println(e.getMessage());
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		
		/*catch(ArithmeticException ex){
			System.out.println(ex.getMessage());
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}*/
		
		/*catch (NumberFormatException e) {
			System.out.println(e.getMessage());
		}
		*/
		
		System.out.println("Program Done!");
		
		
	}

}
