package org.cap.demo;

public class Child extends Parent{
	@Override
	public  Child method(){
		return null;
	}
}
