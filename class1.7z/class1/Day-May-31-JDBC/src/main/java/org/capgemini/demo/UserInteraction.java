package org.capgemini.demo;

import java.util.Scanner;

public class UserInteraction {
	
	Scanner sc=new Scanner(System.in);
	
	public Employee getEmployee(){
		
		Employee employee=new Employee();
		
		System.out.println("Enter Employee Id:");
		employee.setEmpId(sc.nextInt());
		
		System.out.println("Enter Employee FirstName:");
		employee.setFirstName(sc.next());
		
		System.out.println("Enter Employee LastName:");
		employee.setLastName(sc.next());
		
		System.out.println("Enter Employee Salary:");
		employee.setSalary(sc.nextDouble());
		
		System.out.println("Enter Employee Email:");
		employee.setEmail(sc.next());
		
		
		System.out.println("Enter Department Id:");
		Department department=new Department();
		
		department.setDepartmentId(sc.nextInt());
		employee.setDepartmentId(department);
		
		
		
		return employee;
		
	}
	
	
	public String printMessage(int value){
		if(value>0)
			return "Record Inserted";
		else
			return "Record Insertion error!";
	}

}
