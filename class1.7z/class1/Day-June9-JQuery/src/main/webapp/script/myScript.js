jQuery(document).ready(function(){
	$('#change').click(function(){
		$("p").css("color","red");
		$("p").css("font-weight","bold");
		/* $("p").css("font-size","14px"); */
	});
	
	$('#addClass').click(function(){
		$('p').addClass('highlight');
	})
	
	$('#removeClass').click(function(){
		$('p').removeClass('highlight');
	})
	
	$('#toggleClass').click(function(){
		$('p').toggleClass('highlight');
	})
	
	
	
	$('#slideUp').click(function(){
		$('img').slideUp();
	})
	
	$('#slideDown').click(function(){
		$('img').slideDown();
	})
	
	
	$('#fadeIn').click(function(){
		$('img').fadeIn();
	})
	
	$('#fadeOut').click(function(){
		$('img').fadeOut(3000);
	})
	
	$('#fadeToggle').click(function(){
		$('img').fadeToggle();
	})
	
	
	$('#imgAnimate').click(function(){
		$('img').animate({
			'left':'100px',
			'right':'50px',
			'width': '200px',
			'opacity':'0.2'
		},3000);
	});
	
})