$(document).ready(function(){
	
	$('#myCalender').datepicker({
		numberOfMonths:1,
		dateFormat: "yy-mm-dd",
		minDate: new Date(2007, 1 - 1, 1),
		maxDate: new Date(2020,1-1,1)
	});
	
	$('#myCalender').datepicker("setDate", new Date() );
	
})