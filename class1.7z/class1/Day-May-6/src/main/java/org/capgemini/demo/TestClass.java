package org.capgemini.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class TestClass {

	public static void main(String[] args) {
		
      
       
		
		
		/*if(args.length>0)
		{
			System.out.println("Total no of Args:" + args.length);
			
			for(String str:args)
				System.out.println(str);
		}
		
		
		StaticDemo demo=new StaticDemo();
		
		StaticDemo demo1=new StaticDemo();
		
		
		demo.show();
		
		StaticDemo.show();
		
		try {
			Class.forName("org.capgemini.demo.StaticDemo");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

	}
