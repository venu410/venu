package org.cap.demo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {
	
	@Id
	private StudentID studentID;
	private String studName;
	private String courseName;
	
	public Student(){}
	
	public Student(StudentID studentID, String studName, String courseName) {
		super();
		this.studentID = studentID;
		this.studName = studName;
		this.courseName = courseName;
	}
	public StudentID getStudentID() {
		return studentID;
	}
	public void setStudentID(StudentID studentID) {
		this.studentID = studentID;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	@Override
	public String toString() {
		return "Student [studentID=" + studentID + ", studName=" + studName + ", courseName=" + courseName + "]";
	}
	
	

}
