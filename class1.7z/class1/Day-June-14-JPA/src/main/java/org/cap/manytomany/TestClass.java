package org.cap.manytomany;

import org.cap.demo.onetoone.Employee;
import org.cap.demo.onetoone.Employee_Address;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass {

	public static void main(String[] args) {
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Event.class);
		config.addAnnotatedClass(Delegate.class);
		config.configure();
		
		//To Recreate Schema everyTime
		new SchemaExport(config).create(true, true);
		
		Event java=new Event(1001, "JAVA_1001");
		Event oracle=new Event(1004, "ORACLE_1004");
		
		Delegate tom=new Delegate(1, "TOM");
		Delegate jerry=new Delegate(2, "Jerry");
		Delegate jack=new Delegate(3, "Jack");
		Delegate sam=new Delegate(4, "Sam");
		Delegate ram=new Delegate(5, "ram");
		
		tom.getEvents().add(java);
		tom.getEvents().add(oracle);
		
		jerry.getEvents().add(java);
		jerry.getEvents().add(oracle);
		jack.getEvents().add(java);
		sam.getEvents().add(java);
		ram.getEvents().add(oracle);
				
				
		SessionFactory sessfactory=config.buildSessionFactory();
		Session session=sessfactory.openSession();
		session.getTransaction().begin();
		session.save(java);
		session.save(oracle);
		
		session.save(jack);
		session.save(sam);
		session.save(tom);
		session.save(ram);
		session.save(jerry);
		
		session.getTransaction().commit();
		session.close();

	}

}
