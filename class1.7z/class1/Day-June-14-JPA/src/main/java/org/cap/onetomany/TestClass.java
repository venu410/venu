package org.cap.onetomany;


import org.cap.demo.onetoone.Employee_Address;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass {

	public static void main(String[] args) {
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(org.cap.onetomany.Employee.class);
		config.addAnnotatedClass(Company.class);
		config.configure();
		
		//To Recreate Schema everyTime
		new SchemaExport(config).create(true, true);
		
		Company cap=new Company(1001, "Capgemini Consulting Services");
		Company tcs=new Company(1003, "TATA Consultcy Services");
		
		Employee tom=new Employee("Tom", 12000, cap);
		Employee jerry=new Employee("jerry", 3400, cap);
		Employee sam=new Employee("sam", 1200, tcs);
		Employee ram=new Employee("ram", 56000, tcs);
		Employee jack=new Employee("jack", 5656, cap);
		
		
		SessionFactory sessfactory=config.buildSessionFactory();
		Session session=sessfactory.openSession();
		session.getTransaction().begin();
		session.save(tcs);
		session.save(cap);
		
		session.save(tom);
		session.save(jerry);
		session.save(ram);
		session.save(sam);
		session.save(jack);
		
		session.getTransaction().commit();
		session.close();

	}

}
