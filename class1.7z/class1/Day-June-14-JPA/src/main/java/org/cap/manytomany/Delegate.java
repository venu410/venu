package org.cap.manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Delegate {
	
	@Id
	private int delegateId;
	private String delegatename;
	
	@ManyToMany
	@JoinTable(name="Event_Delegate",joinColumns={@JoinColumn(name="delegateId")}, 
				inverseJoinColumns={@JoinColumn(name="eventId")})
	private List<Event> events=new ArrayList<>();
	
	public Delegate(){}
	
	public Delegate(int delegateId, String delegatename) {
		super();
		this.delegateId = delegateId;
		this.delegatename = delegatename;
		
	}

	public Delegate(int delegateId, String delegatename, List<Event> events) {
		super();
		this.delegateId = delegateId;
		this.delegatename = delegatename;
		this.events = events;
	}

	public int getDelegateId() {
		return delegateId;
	}

	public void setDelegateId(int delegateId) {
		this.delegateId = delegateId;
	}

	public String getDelegatename() {
		return delegatename;
	}

	public void setDelegatename(String delegatename) {
		this.delegatename = delegatename;
	}

	public List<Event> getEvents() {
		return events;
	}

	public void setEvents(List<Event> events) {
		this.events = events;
	}

	@Override
	public String toString() {
		return "Delegate [delegateId=" + delegateId + ", delegatename=" + delegatename + ", events=" + events + "]";
	}
	
	

}
