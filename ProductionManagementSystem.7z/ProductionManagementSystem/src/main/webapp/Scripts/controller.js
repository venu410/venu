app.controller("mycontroller",function($scope,$http){
	$scope.getCategories=function(){
		var url="http://localhost:8080/ProductionManagementSystem/CategoryServlet";
		$http.get(url)
		.success(function(response){
			$scope.categories=response;
		})
		.error(function(msg){
			$scope.categories=msg;
		});
	};
	$scope.getSubCategories=function(){
		var url="http://localhost:8080/ProductionManagementSystem/SubCategoryServlet";
		$http.get(url)
		.success(function(response){
			$scope.subCategories=response;
			console.log(subCategories);
		})
		.error(function(msg){
			$scope.subCategories=msg;
		});
	};
	$scope.getDiscounts=function(){
		var url="http://localhost:8080/ProductionManagementSystem/DiscountServlet";
		$http.get(url)
		.success(function(response){
			$scope.discounts=response;
		})
		.error(function(msg){
			$scope.discounts=msg;
		});
	};
	$scope.getSuppliers=function(){
		var url="http://localhost:8080/ProductionManagementSystem/SupllierServlet";
		$http.get(url)
		.success(function(response){
			$scope.suppliers=response;
		})
		.error(function(msg){
			$scope.suppliers=msg;
		});
	};
	$scope.getAllProducts=function(){
		var url="http://localhost:8080/ProductionManagementSystem/ViewAllProductsServlet";
		$http.get(url)
		.success(function(response){
			$scope.allProducts=response;
		})
		.error(function(msg){
			$scope.allProducts=msg;
		});
	};
	$scope.searchMethod = function() {
		var url = "http://localhost:8080/ProductionManagementSystem/JsonControler";
		$http.get(url).success(function(response) {
			$scope.search = response;
		}).error(function(msg) {
			$scope.search = msg;
		});

	};
});