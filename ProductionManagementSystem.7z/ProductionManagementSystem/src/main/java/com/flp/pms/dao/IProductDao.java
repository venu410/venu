package com.flp.pms.dao;

import java.sql.Connection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public interface IProductDao {

	public List<Category> getAllCategory();

	public List<SubCategory> getAllSubCategory();

	public List<Supplier> getAllSuppliers();

	public List<Discount> getAllDiscounts();

	public boolean addProduct(Product product);

	public boolean deleteProduct(int productId);

	/*public Map<Integer, Product> getAllProducts();*/

	public Connection getMySQLConnection();
	public List<Product> getAllProducts();

	public void updateProductName(String pName,int productId);
	public void updateProductExpDate(Date expiryDate,int productId);
	public void updateProductMaxRetailPrice(double mRP, int productId);
	public void updateProductRating(float rating, int productId);
	public void updateProductCategory(int getCategory_Id,int productId);
	public void storeJsonData(String jsoninput);
	public String getJsonData();
}
