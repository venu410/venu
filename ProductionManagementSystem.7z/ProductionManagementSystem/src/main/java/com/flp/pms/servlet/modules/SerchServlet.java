package com.flp.pms.servlet.modules;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;

/**
 * Servlet implementation class SerchServlet
 */
public class SerchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//DataBase db=new DataBase();
				PrintWriter out=response.getWriter();
				Gson myjson=new Gson();
				IProductService iProductService=new ProductServiceImpl();
				 String category=request.getParameter("menu");
				 String value=request.getParameter("search");
				  
				 if(category.equalsIgnoreCase("id"))
				 {
					Product product= iProductService.searchProductId(Integer.parseInt(value));
					 System.out.println(product.getProductName());
					String jsoninput=myjson.toJson(product);
					 iProductService.storeJsonData( jsoninput);
					// response.sendRedirect("Pages/Search.html");
				 }
				 else if(category.equalsIgnoreCase("name"))
				 {
					 List<Product> product= iProductService.searchByProductName(value);
					 String jsoninput=myjson.toJson(product);
					 iProductService.storeJsonData( jsoninput);
					 response.sendRedirect("Pages/Search.html");
				 }
				 else if(category.equalsIgnoreCase("supplier"))
				 {
					 List<Product> product= iProductService.searchBySupplierName(value);
					 String jsoninput=myjson.toJson(product);
					 iProductService.storeJsonData( jsoninput);
					 response.sendRedirect("Pages/Search.html");
				 }
				 else if(category.equalsIgnoreCase("category"))
				 {
					 List<Product> product= iProductService.searchByCategoryName(value);
					 String jsoninput=myjson.toJson(product);
					 iProductService.storeJsonData( jsoninput);
					 response.sendRedirect("Pages/Search.html");
				 }
				 else{}
				/* DataBase db=new DataBase();
				 Product pro=new Product();
				 List<Product> product=db.getAllProducts();
				 for (Product product2 : product) {
					if(product2.getProductId()==Integer.parseInt(value))
						pro=product2;
				}
				 Gson myJson=new Gson();
				 String discount=myJson.toJson(pro);
				 out.println(pro);*/
				 
				 
	}

}
