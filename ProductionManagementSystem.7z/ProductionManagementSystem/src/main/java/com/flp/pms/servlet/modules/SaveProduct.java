package com.flp.pms.servlet.modules;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.ProductDaoImpForJDBC;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;

public class SaveProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//PrintWriter out=response.getWriter();
		IProductService service = new ProductServiceImpl();
		// getting data from browser
		String pName = request.getParameter("pname");
		String pDescr = request.getParameter("ProductDescription");
		String mfd = request.getParameter("mfd");
		String exdate = request.getParameter("exdate");
		String mRP = request.getParameter("MRP");
		String categoryName = request.getParameter("cat");
		String subCategoryName = request.getParameter("subcat");
		String supplierName = request.getParameter("supl");
		String discountName[] = request.getParameterValues("disc");
		String quantity = request.getParameter("Quantity");
		String rating = request.getParameter("rating");
		
		
		// setting data in to pojo classes
		Product product = new Product();
		product.setProductName(pName);
		product.setDescription(pDescr);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-DD");
		try {
			product.setManufacturing_date(sdf.parse(mfd));
			product.setExpiry_date(sdf.parse(exdate));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<Category> categories = service.getAllCategory();
		for (Category category : categories) {
			if (category.getCategory_Name().equalsIgnoreCase(categoryName)) {
				product.setCategory(category);
				break;

			}

		}
List<SubCategory> subCategories=service.getAllSubCategory();
for(SubCategory subCategory:subCategories){
	if(subCategory.getSub_category_Name().equalsIgnoreCase(subCategoryName)){
		product.setSubCategory(subCategory);
		break;
	}
}
List<Supplier> suppliers=service.getAllSupplier();
for(Supplier supplier:suppliers){
	if(supplier.getFirstName().equalsIgnoreCase(supplierName)){
		product.setSupplier(supplier);
		break;
	}
}
List<Discount> discounts=service.getAllDiscounts();
List<Discount> discounts2=new ArrayList<>();
int i=0;
while(i<discountName.length){
	for(Discount discount:discounts){
		if(discount.getDiscountName().equalsIgnoreCase(discountName[i])){
			discounts2.add(discount);
		}
}
	i++;

}
product.setDiscounts(discounts2);
product.setMax_retail_price(Double.parseDouble(mRP));
product.setQuantity(Integer.parseInt(quantity));
product.setRatings(Float.parseFloat(rating));
//out.println(product);
service.addProduct(product);
//System.out.println(product);

	}

}
