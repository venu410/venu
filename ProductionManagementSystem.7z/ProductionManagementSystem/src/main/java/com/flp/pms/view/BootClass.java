
package com.flp.pms.view;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImpForJDBC;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;

public class BootClass {

	public static void main(String[] args) {
		menuSelection();

	}

	public static void menuSelection() {
		int option;
		String choice = null;
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		UserInteraction userInteraction = new UserInteraction();
		IProductService iProductService = new ProductServiceImpl();
	
		do {
			System.out.println("1.Create Product" + "\n2.Modify Product" + "\n3.Remove Product" + "\n4.View All Product"
					+ "\n5.Search Product" + "\n6.Exit");
			System.out.println("Enter your option:");
			option = sc.nextInt();

			switch (option) {
			case 1:
				Product product = userInteraction.addProduct(iProductService.getAllCategory(),
						iProductService.getAllSubCategory(), iProductService.getAllSupplier(),
						iProductService.getAllDiscounts());

				iProductService.addProduct(product);

				break;
			case 2:
				int productId = userInteraction.getProductId();
				Product product2 = iProductService.searchProductId(productId);
				if (product2 != null) {
					System.out.println("1.To update Product Name" + "\n2.To update Expiry Date" + "\n3.To updateMaximum Retail Price"
							+ "\n4.To update Rating" + "\n5.To update Category");
					System.out.println("Enter your option:");
					option = sc.nextInt();
					switch (option) {
					case 1:
						String productName = userInteraction.getProductNameForUpdate();
						iProductService.updateProductName(productName,productId);
						break;
					case 2:
						Date expiryDate = userInteraction.getProductExDateForUpdate();
						iProductService.updateProductExpDate(expiryDate,productId);
						break;
					case 3:
						double mRP = userInteraction.getProductMaxRetailPriceForUpdate();
						iProductService.updateProductMaxRetailPrice(mRP, productId);
						break;

					case 4:
						float rating = userInteraction.getProductRatingForUpdate();
						iProductService.updateProductRating(rating, productId);
						break;
					case 5:
						Category category = userInteraction.getCategory(iProductService.getAllCategory());
						iProductService.updateProductCategory(category.getCategory_Id(), productId);
						break;
					/*case 6:
						Scanner scanner2=new Scanner(System.in);
						int id=scanner2.nextInt()
						iProductService.updateProductCategory(category.getCategory_Id(), productId);
						break;*/
					}
				} else {
					System.out.println("Product Id not found");
				}

				break;
			case 3:

				int productId1 = userInteraction.getProductId();
				userInteraction.getDeleteStatus(iProductService.removeProduct(productId1));
				/*if(iProductService.removeProduct(productId))
					System.out.println("product is deleted succesfully");
				else
					System.out.println("Product Id not found");
				*/
				
				/*if (iProductDao.deleteProduct(productId)) {
					
					
				} else {
					System.out.println("Product Id not found");
				}
*/
				break;
			case 4:
				List<Product> listOfProducts = iProductService.getAllProductsList();
				userInteraction.viewAllProduts(listOfProducts);
				break;
			case 5:
				System.out.println("1.By Name" + "\n2.By Supplier/Producer" + "\n3.By Category" + "\n4.By SubCategory"
						+ "\n5.By Ratings"+"\n 6.Bu productId");
				System.out.println("Enter your option");
				option = sc.nextInt();
				List<Product> searchedProducts = null;
				switch (option) {
				case 1:
					String productName = userInteraction.getProductName();
					searchedProducts = iProductService.searchByProductName(productName);
					userInteraction.showSearchedProduct(searchedProducts);
					break;
				case 2:
					String supplierName = userInteraction.getSupplierName();
					searchedProducts = iProductService.searchBySupplierName(supplierName);
					userInteraction.showSearchedProduct(searchedProducts);
					break;

				case 3:
					String categoryName = userInteraction.getCategoryName();
					searchedProducts = iProductService.searchByCategoryName(categoryName);
					userInteraction.showSearchedProduct(searchedProducts);
					break;
				case 4:
					String subCategoryName = userInteraction.getSubCategoryName();
					searchedProducts = iProductService.searchBySubCategoryName(subCategoryName);
					userInteraction.showSearchedProduct(searchedProducts);
					break;
				case 5:

					float rating = userInteraction.getRating();
					searchedProducts = iProductService.searchByRating(rating);
					userInteraction.showSearchedProduct(searchedProducts);
					break;
				case 6:
					Scanner scanner2=new Scanner(System.in);
					System.out.println("enter the product id");
					int id=scanner2.nextInt();
					iProductService.searchProductId(id);
					break;
				default:
					System.out.println("Invalid input");
					break;

				}

				break;
			case 6:
				System.exit(0);
			}
			System.out.println("You wish to continue?[Y|N]");
			choice = sc.next();
		} while (choice.charAt(0) == 'y' || choice.charAt(0) == 'Y');
	}

}
